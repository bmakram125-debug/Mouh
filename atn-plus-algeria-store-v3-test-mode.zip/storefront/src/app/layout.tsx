import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";
import { CartProvider } from "@/components/cart-context";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import CartDrawer from "@/components/CartDrawer";

export const metadata: Metadata = {
  title: "ATN+ | أزياء عربية بروح عالمية",
  description:
    "متجر ATN+ للملابس: عبايات، أثواب، هوديات، معاطف وفساتين بجودة كوتور. شحن لجميع ولايات الجزائر وإرجاع خلال 14 يوم.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="ar" dir="rtl">
      <body className="bg-sand-100 text-ink-900 antialiased">
        <CartProvider>
          <Header />
          <CartDrawer />
          <div className="min-h-[60vh]">{children}</div>
          <Footer />
        </CartProvider>
      </body>
    </html>
  );
}
