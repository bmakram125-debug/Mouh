import { notFound } from "next/navigation";
import { getProductWithReviews, getShopData } from "@/lib/shop";
import ProductDetail from "@/components/ProductDetail";
import Reviews from "@/components/Reviews";
import type { CardProduct } from "@/components/ProductCard";

export const dynamic = "force-dynamic";

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const data = await getProductWithReviews(slug);
  if (!data) return { title: "منتج غير موجود | ATN+" };
  return {
    title: `${data.product.name} | ATN+`,
    description: data.product.description.slice(0, 150),
  };
}

export default async function ProductPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const data = await getProductWithReviews(slug);
  if (!data) {
    // fallback: try static seed
    const { products } = await getShopData();
    const p = products.find((x) => x.slug === slug);
    if (!p) notFound();
    const related: CardProduct[] = products
      .filter((x) => x.slug !== slug)
      .slice(0, 4)
      .map((x) => ({
        slug: x.slug,
        name: x.name,
        nameEn: x.nameEn,
        price: x.price,
        compareAtPrice: x.compareAtPrice,
        category: x.category,
        images: x.images as string[],
        rating: x.rating,
        reviewCount: x.reviewCount,
        badge: x.badge,
        isNew: x.isNew,
        colors: x.colors as { name: string; hex: string }[],
        sizes: x.sizes as string[],
      }));
    return (
      <main className="mx-auto max-w-7xl px-4 pt-8 md:px-8">
        <ProductDetail
          product={{
            slug: p.slug,
            name: p.name,
            nameEn: p.nameEn,
            description: p.description,
            details: (p.details as string) ?? "",
            price: p.price,
            compareAtPrice: p.compareAtPrice,
            category: p.category,
            images: p.images as string[],
            colors: p.colors as { name: string; hex: string }[],
            sizes: p.sizes as string[],
            fabric: (p.fabric as string) ?? "",
            stock: p.stock,
            rating: p.rating,
            reviewCount: p.reviewCount,
            soldCount: p.soldCount,
            badge: p.badge,
            isNew: p.isNew,
          }}
          related={related}
        />
      </main>
    );
  }

  const { product, reviews, related } = data;
  const relatedCards: CardProduct[] = related.map((x) => ({
    slug: x.slug,
    name: x.name,
    nameEn: x.nameEn,
    price: x.price,
    compareAtPrice: x.compareAtPrice,
    category: x.category,
    images: x.images as string[],
    rating: x.rating,
    reviewCount: x.reviewCount,
    badge: x.badge,
    isNew: x.isNew,
    colors: x.colors as { name: string; hex: string }[],
    sizes: x.sizes as string[],
  }));

  return (
    <main className="mx-auto max-w-7xl px-4 pt-8 md:px-8">
      <ProductDetail
        product={{
          slug: product.slug,
          name: product.name,
          nameEn: product.nameEn,
          description: product.description,
          details: product.details ?? "",
          price: product.price,
          compareAtPrice: product.compareAtPrice,
          category: product.category,
          images: product.images as string[],
          colors: product.colors as { name: string; hex: string }[],
          sizes: product.sizes as string[],
          fabric: product.fabric ?? "",
          stock: product.stock,
          rating: product.rating,
          reviewCount: product.reviewCount,
          soldCount: product.soldCount,
          badge: product.badge,
          isNew: product.isNew,
        }}
        related={relatedCards}
      />
      <Reviews
        productSlug={product.slug}
        avg={product.rating}
        initial={reviews.map((r) => ({
          id: r.id,
          author: r.author,
          city: r.city ?? "تلمسان",
          rating: r.rating,
          title: r.title,
          body: r.body,
          helpful: r.helpful ?? 0,
          verified: r.verified ?? true,
          createdAt: r.createdAt,
        }))}
      />
    </main>
  );
}
