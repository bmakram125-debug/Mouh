import CheckoutClient from "@/components/CheckoutClient";

export const dynamic = "force-dynamic";

export const metadata = {
  title: "إتمام الطلب | ATN+",
  description: "أكمل طلبك بأمان — شحن سريع ودفع متعدد.",
};

export default function CheckoutPage() {
  return (
    <main className="mx-auto max-w-7xl px-4 pt-10 md:px-8">
      <div className="mx-auto max-w-2xl text-center">
        <p className="font-latin text-[11px] font-semibold tracking-[0.35em] text-gold-600 uppercase">Checkout</p>
        <h1 className="font-display mt-2 text-4xl font-bold md:text-5xl">إتمام الطلب</h1>
        <p className="mt-3 text-[14px] leading-7 text-ink-500">خطوات بسيطة ويوصلك طلبك لباب البيت — الدفع آمن والتوصيل سريع.</p>
      </div>
      <div className="mt-8">
        <CheckoutClient />
      </div>
    </main>
  );
}
