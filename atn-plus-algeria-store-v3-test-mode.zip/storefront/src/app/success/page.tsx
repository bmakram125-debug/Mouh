import Link from "next/link";
import { CheckCircle2, Truck, MessageCircle, ArrowLeft } from "lucide-react";

export const dynamic = "force-dynamic";

export default async function SuccessPage({ searchParams }: { searchParams: Promise<{ order?: string }> }) {
  const { order } = await searchParams;
  return (
    <main className="mx-auto max-w-2xl px-4 pt-14">
      <div className="overflow-hidden rounded-[30px] bg-white text-center shadow-xl ring-1 ring-ink-950/8">
        <div className="bg-gradient-to-l from-emerald-700 to-emerald-600 px-8 py-10 text-white">
          <span className="mx-auto grid h-20 w-20 place-items-center rounded-full bg-white/20 backdrop-blur-md">
            <CheckCircle2 size={40} />
          </span>
          <h1 className="font-display mt-4 text-4xl font-bold">شكراً لك! تم استلام طلبك 🎉</h1>
          <p className="mt-2 text-[14px] text-white/85">سنرسل لك تحديثات الشحن على جوالك أولاً بأول.</p>
          {order && (
            <p className="mx-auto mt-4 w-fit rounded-full bg-ink-950/30 px-6 py-2.5 font-latin text-[14px] font-bold tracking-wider backdrop-blur-md" dir="ltr">
              #{order}
            </p>
          )}
        </div>
        <div className="grid gap-3 p-8 text-right md:grid-cols-2">
          <div className="rounded-2xl bg-sand-100 p-5 ring-1 ring-ink-950/5">
            <Truck size={20} className="text-gold-600" />
            <p className="mt-2 text-[14px] font-bold">التوصيل خلال 2-4 أيام</p>
            <p className="mt-1 text-[12.5px] leading-6 text-ink-500">مندوبنا سيتواصل معك قبل الوصول. الشحن مجاني للطلبات فوق 10000 دج.</p>
          </div>
          <div className="rounded-2xl bg-sand-100 p-5 ring-1 ring-ink-950/5">
            <MessageCircle size={20} className="text-gold-600" />
            <p className="mt-2 text-[14px] font-bold">تحتاج مساعدة؟</p>
            <p className="mt-1 text-[12.5px] leading-6 text-ink-500">فريقنا على واتساب يومياً من 9ص إلى 11م لخدمتك.</p>
          </div>
        </div>
        <div className="flex flex-col gap-2 px-8 pb-8 sm:flex-row">
          <Link href="/shop" className="flex flex-1 items-center justify-center gap-2 rounded-2xl bg-ink-950 py-4 text-[14px] font-bold text-sand-100">
            مواصلة التسوق <ArrowLeft size={16} />
          </Link>
          <Link href="/" className="flex-1 rounded-2xl bg-sand-100 py-4 text-center text-[14px] font-bold ring-1 ring-ink-950/10">
            العودة للرئيسية
          </Link>
        </div>
      </div>
    </main>
  );
}
