import { Suspense } from "react";
import { getShopData } from "@/lib/shop";
import ShopClient from "@/components/ShopClient";
import { SectionHeading } from "@/components/ui";

export const dynamic = "force-dynamic";

export const metadata = {
  title: "تسوّق | ATN+",
  description: "تسوّق جميع منتجات ATN+: عبايات، أثواب، هوديات، معاطف والمزيد.",
};

export default async function ShopPage() {
  const { collections, products } = await getShopData();
  const colSlugById = new Map(collections.map((c) => [c.id, c.slug]));
  const cardProducts = products.map((p) => ({
    slug: p.slug,
    name: p.name,
    nameEn: p.nameEn,
    price: p.price,
    compareAtPrice: p.compareAtPrice,
    category: p.category,
    images: p.images as string[],
    rating: p.rating,
    reviewCount: p.reviewCount,
    badge: p.badge,
    isNew: p.isNew,
    colors: p.colors as { name: string; hex: string }[],
    sizes: p.sizes as string[],
    _col: colSlugById.get(p.collectionId ?? "") ?? "",
    _sold: p.soldCount,
    _new: p.isNew,
  }));
  const categories = Array.from(new Set(products.map((p) => p.category)));

  return (
    <main className="mx-auto max-w-7xl px-4 pt-12 md:px-8">
      <SectionHeading kicker="Shop" title="تسوّق تشكيلات ATN+" sub="استخدم الفلاتر الذكية للوصول لقطعتك المثالية — بالسعر والمقاس والتقييم الذي يناسبك." />
      <div className="mt-10">
        <Suspense fallback={<div className="rounded-3xl bg-white p-10 text-center ring-1 ring-ink-950/5">جاري تحميل المتجر...</div>}>
          <ShopClient
            products={cardProducts}
            collections={collections.map((c) => ({ slug: c.slug, name: c.name }))}
            categories={categories}
          />
        </Suspense>
      </div>
    </main>
  );
}
