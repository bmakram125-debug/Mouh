import { ensureSeeded, getShopData } from "@/lib/shop";

export const dynamic = "force-dynamic";

export async function GET() {
  await ensureSeeded();
  const { collections, products } = await getShopData();
  return Response.json({ ok: true, collections: collections.length, products: products.length });
}

export async function POST() {
  await ensureSeeded();
  const { collections, products } = await getShopData();
  return Response.json({ ok: true, collections: collections.length, products: products.length });
}
