import { db } from "@/db";
import { collections } from "@/db/schema";
import { ensureSeeded } from "@/lib/shop";

export const dynamic = "force-dynamic";

export async function GET() {
  await ensureSeeded();
  try {
    const rows = await db.select().from(collections);
    return Response.json({ collections: rows });
  } catch {
    const { seedCollections } = await import("@/lib/seed-data");
    return Response.json({ collections: seedCollections, fallback: true });
  }
}
