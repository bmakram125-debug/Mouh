import { db } from "@/db";
import { orders, products } from "@/db/schema";
import { ensureSeeded } from "@/lib/shop";
import { eq, sql, inArray } from "drizzle-orm";

export const dynamic = "force-dynamic";

function orderNo() {
  const d = new Date();
  const rand = Math.floor(1000 + Math.random() * 9000);
  return `ATN-DZ-${d.getFullYear()}${String(d.getMonth() + 1).padStart(2, "0")}${String(d.getDate()).padStart(2, "0")}-${rand}`;
}
function cleanString(value: unknown, max: number) { return String(value ?? "").trim().slice(0, max); }

export async function POST(req: Request) {
  try {
    const b = await req.json();
    const customerName = cleanString(b.customerName, 100);
    const phone = cleanString(b.phone, 20).replace(/[\s-]/g, "");
    const email = cleanString(b.email, 120);
    const city = cleanString(b.city, 60);
    const address = cleanString(b.address, 500);
    const notes = cleanString(b.notes, 500);
    const paymentMethod = b.paymentMethod === "online" ? "online" : "cod";
    if (customerName.length < 3) return Response.json({ error: "فضلاً أدخل الاسم الكامل" }, { status: 400 });
    if (!/^(0)(5|6|7)[0-9]{8}$/.test(phone)) return Response.json({ error: "رقم الهاتف الجزائري غير صحيح" }, { status: 400 });
    if (address.length < 8) return Response.json({ error: "فضلاً أدخل عنواناً تفصيلياً" }, { status: 400 });
    if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return Response.json({ error: "البريد الإلكتروني غير صحيح" }, { status: 400 });
    if (!Array.isArray(b.items) || b.items.length === 0 || b.items.length > 50) return Response.json({ error: "السلة فارغة أو غير صالحة" }, { status: 400 });
    await ensureSeeded();
    if (paymentMethod === "online" && !process.env.CHARGILY_SECRET_KEY) return Response.json({ error: "الدفع الإلكتروني غير مفعّل بعد: أضف CHARGILY_SECRET_KEY إلى البيئة." }, { status: 503 });
    const requested = b.items.map((i: any) => ({ slug: cleanString(i.slug, 160), qty: Math.floor(Number(i.qty)), size: cleanString(i.size, 30), color: cleanString(i.color, 60) }));
    if (requested.some((i: any) => !i.slug || !Number.isInteger(i.qty) || i.qty < 1 || i.qty > 20)) return Response.json({ error: "بيانات المنتجات غير صالحة" }, { status: 400 });
    const uniqueSlugs = [...new Set(requested.map((i: any) => i.slug))];
    const dbProducts = await db.select().from(products).where(inArray(products.slug, uniqueSlugs));
    const bySlug = new Map(dbProducts.map((p) => [p.slug, p]));
    const items = requested.map((i: any) => {
      const p = bySlug.get(i.slug);
      if (!p) throw new Error(`المنتج غير موجود: ${i.slug}`);
      if (i.qty > p.stock) throw new Error(`الكمية المطلوبة من «${p.name}» غير متوفرة`);
      if (p.sizes.length && !p.sizes.includes(i.size)) throw new Error(`المقاس غير متوفر للمنتج «${p.name}»`);
      if (p.colors.length && !p.colors.some((c) => c.name === i.color)) throw new Error(`اللون غير متوفر للمنتج «${p.name}»`);
      return { slug: p.slug, name: p.name, image: p.images[0] ?? "", price: p.price, qty: i.qty, size: i.size, color: i.color };
    });
    const subtotal = items.reduce((s, i) => s + i.price * i.qty, 0);
    const coupon = cleanString(b.coupon, 20).toUpperCase();
    const discountRate = coupon === "DZ15" ? 0.15 : coupon === "DZ10" ? 0.10 : 0;
    const discount = Math.round(subtotal * discountRate);
    const shippingMethod = b.shippingMethod === "express" ? "express" : "standard";
    let shipping = shippingMethod === "express" ? 1500 : 800;
    if (subtotal - discount >= 10000) shipping = shippingMethod === "express" ? 500 : 0;
    const total = Math.max(0, subtotal - discount + shipping);
    const number = orderNo();

    await db.transaction(async (tx) => {
      for (const item of items) {
        const updated = await tx.update(products)
          .set({ stock: sql`${products.stock} - ${item.qty}`, soldCount: sql`${products.soldCount} + ${item.qty}` })
          .where(sql`${eq(products.slug, item.slug)} and ${products.stock} >= ${item.qty}`)
          .returning({ id: products.id });
        if (updated.length !== 1) throw new Error(`نفدت كمية «${item.name}» أثناء إتمام الطلب، حاول مرة أخرى`);
      }
      await tx.insert(orders).values({
        orderNumber: number, customerName, phone, email: email || null, city: city || "أخرى", address, notes: notes || null,
        paymentMethod, paymentProvider: paymentMethod === "online" ? "chargily" : "cod", items, subtotal, shipping, discount, total,
        status: paymentMethod === "online" ? "awaiting_payment" : "pending",
      });
    });

    if (paymentMethod === "online") {
      const secret = process.env.CHARGILY_SECRET_KEY!;
      const base = process.env.CHARGILY_API_BASE || (process.env.CHARGILY_MODE === "live" ? "https://pay.chargily.net/api/v2" : "https://pay.chargily.net/test/api/v2");
      const site = process.env.NEXT_PUBLIC_SITE_URL || new URL(req.url).origin;
      const checkout = await fetch(`${base}/checkouts`, {
        method: "POST", headers: { Authorization: `Bearer ${secret}`, "Content-Type": "application/json" },
        body: JSON.stringify({ amount: total, currency: "dzd", payment_method: "edahabia", success_url: `${site}/success?order=${number}&paid=1`, failure_url: `${site}/checkout?payment=failed&order=${number}`, webhook_endpoint: `${site}/api/payments/chargily/webhook`, locale: "ar", description: `طلب ${number}`, metadata: { order_number: number }, shipping_address: `${city}، ${address}`, collect_shipping_address: false, chargily_pay_fees_allocation: "customer" }),
      });
      const cj = await checkout.json();
      if (!checkout.ok || !cj.checkout_url) throw new Error(cj.message || "تعذر إنشاء جلسة الدفع الإلكتروني");
      await db.update(orders).set({ paymentId: cj.id }).where(eq(orders.orderNumber, number));
      return Response.json({ ok: true, paymentRequired: true, checkoutUrl: cj.checkout_url, orderNumber: number, total }, { status: 201 });
    }
    return Response.json({ ok: true, paymentRequired: false, orderNumber: number, subtotal, shipping, discount, total }, { status: 201 });
  } catch (e) {
    const message = e instanceof Error ? e.message : "تعذر إتمام الطلب، حاول مجدداً";
    return Response.json({ error: message }, { status: 400 });
  }
}
