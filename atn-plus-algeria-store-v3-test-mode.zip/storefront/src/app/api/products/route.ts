import { db } from "@/db";
import { products } from "@/db/schema";
import { ensureSeeded } from "@/lib/shop";

export const dynamic = "force-dynamic";

export async function GET() {
  await ensureSeeded();
  try {
    const rows = await db.select().from(products);
    return Response.json({ products: rows });
  } catch {
    const { seedProducts, seedCollections } = await import("@/lib/seed-data");
    const fallback = seedProducts.map((p, i) => ({
      id: `fallback-${i}`,
      slug: p.slug,
      name: p.name,
      nameEn: p.nameEn,
      description: p.description,
      details: p.details,
      price: p.price,
      compareAtPrice: p.compareAtPrice ?? null,
      category: p.category,
      categoryEn: p.categoryEn,
      collectionId: p.collectionSlug,
      images: p.images,
      colors: p.colors,
      sizes: p.sizes,
      fabric: p.fabric,
      stock: p.stock,
      rating: p.rating,
      reviewCount: p.reviewCount,
      soldCount: p.soldCount,
      isFeatured: p.isFeatured,
      isNew: p.isNew,
      badge: p.badge ?? null,
      tags: p.tags,
      createdAt: new Date().toISOString(),
    }));
    return Response.json({ products: fallback, fallback: true });
  }
}
