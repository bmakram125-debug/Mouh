export const dynamic="force-dynamic";
export async function POST(req:Request){
 const b=await req.json(); const base=process.env.DZSHIP_BASE_URL||"https://freeship.dzbuild.com"; const courier=process.env.DZSHIP_COURIER||"sandbox";
 try{const r=await fetch(`${base}/v1/rates`,{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify({courier,credentials:credentials(),query:{fromWilaya:Number(process.env.STORE_WILAYA_CODE||13),toWilaya:Number(b.wilayaCode),deliveryType:b.deliveryType||"home"}})}); const data=await r.json(); if(!r.ok) throw new Error(data?.error||"تعذر حساب الشحن"); return Response.json(data);}catch(e){return Response.json({error:e instanceof Error?e.message:"تعذر حساب الشحن"},{status:400});}
}
function credentials(){const c=process.env.DZSHIP_CREDENTIALS_JSON; if(c)try{return JSON.parse(c)}catch{} return undefined;}
