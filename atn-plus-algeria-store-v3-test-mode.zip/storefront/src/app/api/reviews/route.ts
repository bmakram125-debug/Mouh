import { db } from "@/db";
import { products, reviews } from "@/db/schema";
import { eq } from "drizzle-orm";
import { ensureSeeded } from "@/lib/shop";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  const url = new URL(req.url);
  const slug = url.searchParams.get("productSlug");
  await ensureSeeded();
  try {
    if (slug) {
      const p = await db.select().from(products).where(eq(products.slug, slug)).limit(1);
      if (p.length === 0) return Response.json({ reviews: [] });
      const rows = await db.select().from(reviews).where(eq(reviews.productId, p[0].id));
      return Response.json({ reviews: rows });
    }
    const rows = await db.select().from(reviews).limit(50);
    return Response.json({ reviews: rows });
  } catch {
    return Response.json({ reviews: [] });
  }
}

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const { productSlug, author, city, rating, title, body: text } = body;
    if (!productSlug || !author?.trim() || !text?.trim()) {
      return Response.json({ error: "بيانات ناقصة" }, { status: 400 });
    }
    await ensureSeeded();
    const p = await db.select().from(products).where(eq(products.slug, productSlug)).limit(1);
    if (p.length === 0) return Response.json({ error: "المنتج غير موجود" }, { status: 404 });
    const [row] = await db
      .insert(reviews)
      .values({
        productId: p[0].id,
        author: String(author).slice(0, 60),
        city: String(city ?? "تلمسان").slice(0, 40),
        rating: Math.min(5, Math.max(1, Number(rating) || 5)),
        title: String(title ?? "تقييم").slice(0, 120) || "تقييم",
        body: String(text).slice(0, 1000),
        verified: false,
        helpful: 0,
      })
      .returning();
    // update aggregate (best-effort)
    try {
      const all = await db.select().from(reviews).where(eq(reviews.productId, p[0].id));
      const avg = all.reduce((s, r) => s + r.rating, 0) / Math.max(1, all.length);
      await db
        .update(products)
        .set({ rating: Math.round(avg * 10) / 10, reviewCount: all.length })
        .where(eq(products.id, p[0].id));
    } catch {}
    return Response.json({ review: row }, { status: 201 });
  } catch (e) {
    return Response.json({ error: "تعذر حفظ التقييم" }, { status: 500 });
  }
}
