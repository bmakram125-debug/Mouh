import { db } from "@/db";
import { products } from "@/db/schema";
import { ensureSeeded } from "@/lib/shop";
import { eq } from "drizzle-orm";
import { cookies } from "next/headers";
import { ADMIN_COOKIE, isValidAdminToken } from "@/lib/admin-auth";
async function guard(){const c=await cookies();return isValidAdminToken(c.get(ADMIN_COOKIE)?.value)}
const clean=(v:unknown,max=500)=>String(v??"").trim().slice(0,max);
const arr=(v:unknown)=>Array.isArray(v)?v.map(String).map(s=>s.trim()).filter(Boolean):[];
const colorArr=(v:unknown)=>Array.isArray(v)?v.map((x:any)=>({name:clean(x?.name,60),hex:clean(x?.hex,20)})).filter(x=>x.name):[];
export async function GET(){if(!await guard())return Response.json({error:"غير مصرح"},{status:401});await ensureSeeded();return Response.json({products:await db.select().from(products)});}
function values(b:any){return {slug:clean(b.slug,160).toLowerCase().replace(/\s+/g,"-"),name:clean(b.name,160),nameEn:clean(b.nameEn,160)||clean(b.name,160),description:clean(b.description,2000),details:clean(b.details,2000),price:Math.max(0,Math.round(Number(b.price)||0)),compareAtPrice:b.compareAtPrice===null||b.compareAtPrice===""?null:Math.max(0,Math.round(Number(b.compareAtPrice)||0)),category:clean(b.category,80)||"ملابس",categoryEn:clean(b.categoryEn,80),collectionId:b.collectionId||null,images:arr(b.images),colors:colorArr(b.colors),sizes:arr(b.sizes),fabric:clean(b.fabric,120)||"قطن فاخر",stock:Math.max(0,Math.floor(Number(b.stock)||0)),isFeatured:!!b.isFeatured,isNew:!!b.isNew,badge:clean(b.badge,60)||null,tags:arr(b.tags)}}
export async function POST(req:Request){if(!await guard())return Response.json({error:"غير مصرح"},{status:401});try{const v=values(await req.json());if(!v.slug||!v.name)return Response.json({error:"الاسم والرابط مطلوبان"},{status:400});const [row]=await db.insert(products).values(v).returning();return Response.json({product:row},{status:201})}catch(e){return Response.json({error:e instanceof Error?e.message:"تعذر إنشاء المنتج"},{status:400})}}
export async function PUT(req:Request){if(!await guard())return Response.json({error:"غير مصرح"},{status:401});try{const b=await req.json();if(!b.id)return Response.json({error:"معرف المنتج مطلوب"},{status:400});const v=values(b);const [row]=await db.update(products).set(v).where(eq(products.id,String(b.id))).returning();if(!row)return Response.json({error:"المنتج غير موجود"},{status:404});return Response.json({product:row})}catch(e){return Response.json({error:e instanceof Error?e.message:"تعذر حفظ المنتج"},{status:400})}}
export async function DELETE(req:Request){if(!await guard())return Response.json({error:"غير مصرح"},{status:401});const b=await req.json().catch(()=>({}));const [row]=await db.delete(products).where(eq(products.id,String(b.id||""))).returning({id:products.id});if(!row)return Response.json({error:"المنتج غير موجود"},{status:404});return Response.json({ok:true})}
