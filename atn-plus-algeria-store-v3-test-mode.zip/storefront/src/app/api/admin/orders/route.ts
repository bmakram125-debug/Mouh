import { db } from "@/db";
import { orders } from "@/db/schema";
import { desc, eq } from "drizzle-orm";
import { cookies } from "next/headers";
import { ADMIN_COOKIE, isValidAdminToken } from "@/lib/admin-auth";
async function guard(){const c=await cookies();return isValidAdminToken(c.get(ADMIN_COOKIE)?.value)}
const allowed=["pending","confirmed","processing","shipped","delivered","cancelled"];
export async function GET(){if(!await guard())return Response.json({error:"غير مصرح"},{status:401});return Response.json({orders:await db.select().from(orders).orderBy(desc(orders.createdAt))})}
export async function PATCH(req:Request){if(!await guard())return Response.json({error:"غير مصرح"},{status:401});const b=await req.json();if(!b.id||!allowed.includes(b.status))return Response.json({error:"حالة غير صالحة"},{status:400});const [row]=await db.update(orders).set({status:b.status}).where(eq(orders.id,String(b.id))).returning();if(!row)return Response.json({error:"الطلب غير موجود"},{status:404});return Response.json({order:row})}
