import { cookies } from "next/headers";
import { adminCookie, makeAdminToken, requireAdminPassword } from "@/lib/admin-auth";

export async function POST(req: Request) {
  try {
    const { password } = await req.json();
    if (!requireAdminPassword(String(password || ""))) return Response.json({ error: "كلمة المرور غير صحيحة" }, { status: 401 });
    (await cookies()).set(adminCookie, makeAdminToken(), { httpOnly: true, sameSite: "lax", secure: process.env.NODE_ENV === "production", path: "/", maxAge: 60 * 60 * 24 * 7 });
    return Response.json({ ok: true });
  } catch (e) { return Response.json({ error: e instanceof Error ? e.message : "تعذر تسجيل الدخول" }, { status: 500 }); }
}
export async function DELETE() { (await cookies()).delete(adminCookie); return Response.json({ ok: true }); }
