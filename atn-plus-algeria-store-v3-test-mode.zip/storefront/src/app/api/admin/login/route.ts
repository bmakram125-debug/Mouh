import { NextResponse } from "next/server";
import { ADMIN_COOKIE, adminSecret, makeAdminToken } from "@/lib/admin-auth";
export async function POST(req: Request) {
  const body = await req.json().catch(() => ({}));
  if (!adminSecret() || String(body.password ?? "") !== adminSecret()) return Response.json({ error: "كلمة المرور غير صحيحة" }, { status: 401 });
  const res = NextResponse.json({ ok: true });
  res.cookies.set(ADMIN_COOKIE, makeAdminToken(), { httpOnly:true, sameSite:"lax", secure:process.env.NODE_ENV === "production", path:"/", maxAge:43200 });
  return res;
}
