import Link from "next/link";
import Image from "next/image";
import { ArrowLeft, ArrowDown, Star, Truck, ShieldCheck, Sparkles, Flame, Scissors, HeartHandshake } from "lucide-react";
import { getShopData } from "@/lib/shop";
import ProductCard from "@/components/ProductCard";
import { Marquee, Reveal, SectionHeading, Stars } from "@/components/ui";
import { formatPrice } from "@/lib/format";

export const dynamic = "force-dynamic";

export default async function HomePage() {
  const { collections, products } = await getShopData();
  const featured = products.filter((p) => p.isFeatured).slice(0, 8);
  const best = [...products].sort((a, b) => b.soldCount - a.soldCount).slice(0, 4);
  const heroImg = products.find((p) => p.slug === "classic-black-abaya")?.images[0] ?? collections[0]?.image;
  const heroImg2 = products.find((p) => p.slug === "iconic-black-hoodie")?.images[0] ?? collections[1]?.image;

  return (
    <main>
      {/* HERO */}
      <section className="relative overflow-hidden">
        <div className="pointer-events-none absolute -top-32 -left-32 h-[480px] w-[480px] rounded-full bg-gold-500/20 blur-[120px]" />
        <div className="pointer-events-none absolute top-40 -right-32 h-[380px] w-[380px] rounded-full bg-clay-500/15 blur-[120px]" />

        <div className="mx-auto grid max-w-7xl items-center gap-10 px-4 pt-10 pb-14 md:grid-cols-2 md:px-8 md:pt-16 md:pb-20">
          {/* copy */}
          <div className="relative z-10">
            <Reveal>
              <div className="inline-flex items-center gap-2 rounded-full bg-white px-4 py-2 text-[12px] font-bold text-ink-800 ring-1 ring-ink-950/10 shadow-sm">
                <span className="relative flex h-2 w-2">
                  <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-500 opacity-60" />
                  <span className="relative inline-flex h-2 w-2 rounded-full bg-emerald-600" />
                </span>
                تشكيلة شتاء 2026 وصلت حديثاً
                <Sparkles size={14} className="text-gold-600" />
              </div>
            </Reveal>
            <Reveal delay={1}>
              <h1 className="font-display mt-6 text-[44px] leading-[1.2] font-bold text-ink-950 md:text-[68px] md:leading-[1.15]">
                أناقة عربية،
                <br />
                <span className="relative inline-block">
                  بمعايير عالمية
                  <svg viewBox="0 0 300 14" className="absolute -bottom-2 right-0 w-full" fill="none">
                    <path d="M4 10C80 3 200 3 296 8" stroke="#C9A86A" strokeWidth="5" strokeLinecap="round" />
                  </svg>
                </span>
              </h1>
            </Reveal>
            <Reveal delay={2}>
              <p className="mt-6 max-w-md text-[15.5px] leading-8 text-ink-500">
                من العباية اليومية إلى الهودي الأيقوني — قطع مصممة بعناية، مخيطة بإتقان، وبأسعار عادلة. اكتشف لماذا اختارنا أكثر من <b className="text-ink-900">12,000 عميل</b> هذا العام.
              </p>
            </Reveal>
            <Reveal delay={3}>
              <div className="mt-8 flex flex-wrap items-center gap-3">
                <Link
                  href="/shop"
                  className="group flex items-center gap-2 rounded-full bg-ink-950 px-8 py-4 text-[14px] font-bold text-sand-100 shadow-[0_18px_40px_rgba(20,16,12,0.3)] transition-all hover:scale-[1.02] hover:bg-ink-800"
                >
                  تسوّق التشكيلة
                  <ArrowLeft size={17} className="transition-transform group-hover:-translate-x-1" />
                </Link>
                <Link
                  href="/shop?collection=modest"
                  className="rounded-full bg-white px-8 py-4 text-[14px] font-bold text-ink-950 ring-1 ring-ink-950/12 transition-all hover:ring-ink-950"
                >
                  عبايات ATN+
                </Link>
              </div>
            </Reveal>
            <Reveal delay={3}>
              <div className="mt-10 flex items-center gap-6">
                <div className="flex -space-x-3 space-x-reverse">
                  {products.slice(0, 4).map((p) => (
                    <span key={p.slug} className="relative h-11 w-11 overflow-hidden rounded-full ring-[2.5px] ring-sand-100">
                      <Image src={p.images[0]} alt="" fill className="object-cover" sizes="44px" />
                    </span>
                  ))}
                  <span className="grid h-11 w-11 place-items-center rounded-full bg-ink-950 text-[11px] font-bold text-sand-100 ring-[2.5px] ring-sand-100">
                    +12k
                  </span>
                </div>
                <div>
                  <div className="flex items-center gap-1.5">
                    <Stars value={4.8} />
                    <b className="text-[13px]">4.8</b>
                  </div>
                  <p className="mt-0.5 text-[12px] text-ink-500">من +2,400 تقييم موثّق</p>
                </div>
              </div>
            </Reveal>
          </div>

          {/* visual */}
          <div className="relative">
            <Reveal delay={1} className="relative">
              <div className="relative mx-auto grid max-w-[520px] grid-cols-12 gap-4">
                <div className="card-zoom relative col-span-7 aspect-[3/4.4] overflow-hidden rounded-[28px] shadow-2xl ring-1 ring-ink-950/10">
                  {heroImg && <Image src={heroImg} alt="عباية ATN+" fill className="object-cover" priority sizes="(max-width:768px) 60vw, 340px" />}
                  <div className="absolute inset-0 bg-gradient-to-t from-ink-950/35 to-transparent" />
                  <div className="absolute bottom-4 right-4 left-4 flex items-end justify-between text-white">
                    <div>
                      <p className="text-[11px] text-white/70">الأعلى تقييماً</p>
                      <p className="text-[15px] font-bold">عباية انسيابية كلاسيكية</p>
                    </div>
                    <span className="rounded-full bg-white/20 px-3 py-1.5 text-[12px] font-bold backdrop-blur-md">{formatPrice(349)}</span>
                  </div>
                </div>
                <div className="col-span-5 flex flex-col gap-4">
                  <div className="card-zoom relative aspect-[3/3.6] overflow-hidden rounded-[28px] shadow-xl ring-1 ring-ink-950/10">
                    {heroImg2 && <Image src={heroImg2} alt="هودي ATN+" fill className="object-cover" sizes="(max-width:768px) 40vw, 220px" />}
                  </div>
                  <div className="animate-float rounded-[28px] bg-ink-950 p-5 text-sand-100 shadow-xl">
                    <p className="font-latin text-[11px] tracking-[0.25em] text-gold-400">ATN+ CLUB</p>
                    <p className="mt-1 text-[15px] font-bold">خصم 15% على أول طلب</p>
                    <p className="mt-1 text-[12px] text-white/60">بكود: DZ15</p>
                  </div>
                </div>
                {/* floating badges */}
                <div className="absolute -right-3 top-8 flex items-center gap-2 rounded-2xl bg-white/90 px-4 py-2.5 shadow-xl backdrop-blur-md md:-right-8">
                  <span className="grid h-9 w-9 place-items-center rounded-full bg-emerald-100 text-emerald-700">
                    <Truck size={16} />
                  </span>
                  <span className="text-[12px] font-bold">شحن خلال 48 ساعة</span>
                </div>
                <div className="absolute -left-2 bottom-24 flex items-center gap-2 rounded-2xl bg-white/90 px-4 py-2.5 shadow-xl backdrop-blur-md md:-left-6">
                  <span className="grid h-9 w-9 place-items-center rounded-full bg-gold-500/20 text-gold-700">
                    <ShieldCheck size={16} />
                  </span>
                  <span className="text-[12px] font-bold">إرجاع مجاني 14 يوم</span>
                </div>
              </div>
            </Reveal>
          </div>
        </div>

        <div className="flex justify-center pb-8">
          <a href="#collections" className="grid h-11 w-11 animate-bounce place-items-center rounded-full bg-white text-ink-500 ring-1 ring-ink-950/10">
            <ArrowDown size={18} />
          </a>
        </div>
      </section>

      <Marquee
        items={[
          "شحن مجاني فوق 10000 دج",
          "عبايات بقماش ندى كوري",
          "هوديات بوزن 400غ",
          "إرجاع مجاني 14 يوم",
          "تقسيط على 4 دفعات مع تابي",
          "تقييم 4.8 من عملائنا",
        ]}
      />

      {/* COLLECTIONS */}
      <section id="collections" className="mx-auto max-w-7xl scroll-mt-24 px-4 pt-20 md:px-8">
        <SectionHeading kicker="Collections" title="تسوّق حسب التشكيلة" sub="أربع عوالم صممناها بعناية — اختر عالمك واكتشف قطعاً تشبهك." />
        <div className="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {collections
            .sort((a, b) => a.sort - b.sort)
            .map((c, i) => {
              const count = products.filter((p) => p.collectionId === c.id).length;
              return (
                <Reveal key={c.slug} delay={(i % 4 === 0 ? undefined : i % 4 === 1 ? 1 : i % 4 === 2 ? 2 : 3) as 1 | 2 | 3 | undefined}>
                  <Link
                    href={`/shop?collection=${c.slug}`}
                    className="card-zoom group relative block aspect-[3/4] overflow-hidden rounded-[26px] shadow-lg ring-1 ring-ink-950/10"
                  >
                    <Image src={c.image} alt={c.name} fill className="object-cover" sizes="(max-width:768px) 100vw, 25vw" />
                    <div className="absolute inset-0 bg-gradient-to-t from-ink-950/85 via-ink-950/20 to-transparent" />
                    <div className="absolute inset-x-0 bottom-0 p-5 text-white">
                      <p className="font-latin text-[10px] tracking-[0.3em] text-gold-300">{c.nameEn.toUpperCase()}</p>
                      <h3 className="font-display mt-1 text-[26px] font-bold">{c.name}</h3>
                      <p className="mt-1 text-[12.5px] text-white/70">{c.tagline} • {count} منتجات</p>
                      <span className="mt-4 inline-flex items-center gap-2 rounded-full bg-white/15 px-4 py-2 text-[12.5px] font-bold backdrop-blur-md transition-all group-hover:bg-sand-100 group-hover:text-ink-950">
                        اكتشف الآن <ArrowLeft size={14} />
                      </span>
                    </div>
                  </Link>
                </Reveal>
              );
            })}
        </div>
      </section>

      {/* BEST SELLERS */}
      <section className="mx-auto max-w-7xl px-4 pt-20 md:px-8">
        <div className="flex flex-wrap items-end justify-between gap-4">
          <div>
            <p className="font-latin text-[11px] font-semibold tracking-[0.35em] text-gold-600 uppercase">Best sellers</p>
            <h2 className="font-display mt-2 flex items-center gap-3 text-4xl font-bold md:text-5xl">
              الأكثر مبيعاً <Flame className="text-clay-500" size={30} />
            </h2>
            <p className="mt-3 max-w-lg text-[14.5px] leading-7 text-ink-500">القطع التي يعشقها عملاؤنا ويعيدون طلبها — كميات محدودة وتُباع بسرعة.</p>
          </div>
          <Link href="/shop?sort=best" className="group flex items-center gap-2 rounded-full bg-ink-950 px-6 py-3.5 text-[13.5px] font-bold text-sand-100">
            عرض الكل <ArrowLeft size={16} className="transition-transform group-hover:-translate-x-1" />
          </Link>
        </div>
        <div className="mt-8 grid grid-cols-2 gap-4 md:gap-6 lg:grid-cols-4">
          {best.map((p, i) => (
            <ProductCard key={p.slug} index={i} p={{ ...p, images: p.images as string[], colors: p.colors as { name: string; hex: string }[], sizes: p.sizes as string[] }} />
          ))}
        </div>
      </section>

      {/* STORY / CRAFT */}
      <section className="mx-auto max-w-7xl px-4 pt-20 md:px-8">
        <Reveal>
          <div className="grain relative overflow-hidden rounded-[32px] bg-ink-950 text-sand-100">
            <div className="grid md:grid-cols-2">
              <div className="relative min-h-[320px] md:min-h-[520px]">
                <Image
                  src={products.find((p) => p.slug === "gold-embroidered-abaya")?.images[0] ?? collections[2]?.image ?? ""}
                  alt="حرفة ATN+"
                  fill
                  className="object-cover"
                  sizes="(max-width:768px) 100vw, 50vw"
                />
                <div className="absolute inset-0 bg-gradient-to-l from-transparent to-ink-950/40 md:bg-gradient-to-r md:from-ink-950/30 md:to-transparent" />
              </div>
              <div className="flex flex-col justify-center p-8 md:p-14">
                <p className="font-latin text-[11px] tracking-[0.35em] text-gold-400">OUR CRAFT — حرفتنا</p>
                <h3 className="font-display mt-4 text-3xl leading-snug font-bold md:text-[42px] md:leading-[1.3]">
                  لا نبيع الملابس،
                  <br />
                  نصنع <span className="text-gold-300">الثقة</span> التي تلبسها
                </h3>
                <p className="mt-5 text-[14.5px] leading-8 text-white/65">
                  كل قطعة تمر بـ 27 مرحلة فحص: من اختيار القماش، إلى القصّ، إلى الغرزة الأخيرة. نتعامل مع مصانع عائلية تدفع أجوراً عادلة، ونستخدم أقمشة تدوم لسنوات لا لمواسم.
                </p>
                <div className="mt-8 grid grid-cols-3 gap-4">
                  {[
                    { n: "27", l: "مرحلة فحص جودة" },
                    { n: "100%", l: "أقمشة مختارة بعناية" },
                    { n: "14 يوم", l: "إرجاع مجاني" },
                  ].map((s) => (
                    <div key={s.l} className="rounded-2xl bg-white/6 p-4 text-center ring-1 ring-white/10">
                      <p className="font-latin text-2xl font-bold text-gold-300">{s.n}</p>
                      <p className="mt-1 text-[11.5px] text-white/60">{s.l}</p>
                    </div>
                  ))}
                </div>
                <div className="mt-8 flex flex-wrap gap-3">
                  <Link href="/shop" className="rounded-full bg-sand-100 px-7 py-3.5 text-[13.5px] font-bold text-ink-950 transition-transform hover:scale-[1.02]">
                    اكتشف الجودة
                  </Link>
                  <span className="flex items-center gap-2 px-2 text-[12.5px] text-white/55">
                    <Scissors size={15} /> خياطة يابانية دقيقة
                  </span>
                </div>
              </div>
            </div>
          </div>
        </Reveal>
      </section>

      {/* FEATURED GRID */}
      <section className="mx-auto max-w-7xl px-4 pt-20 md:px-8">
        <SectionHeading kicker="New & Featured" title="مختارات هذا الأسبوع" sub="قطع مختارة بعناية من فريق التصميم — جديدة، مميزة، وبكميات محدودة." />
        <div className="mt-10 grid grid-cols-2 gap-4 md:gap-6 lg:grid-cols-4">
          {featured.map((p, i) => (
            <ProductCard key={p.slug} index={i} p={{ ...p, images: p.images as string[], colors: p.colors as { name: string; hex: string }[], sizes: p.sizes as string[] }} />
          ))}
        </div>
      </section>

      {/* TESTIMONIALS */}
      <section className="mt-20 bg-sand-200/60 py-16">
        <div className="mx-auto max-w-7xl px-4 md:px-8">
          <SectionHeading kicker="Reviews" title="ماذا يقول ناسنا؟" sub="تقييمات حقيقية من عملاء اشتروا ولبسوا وجرّبوا." />
          <div className="mt-10 grid gap-5 md:grid-cols-3">
            {[
              { n: "ريم الحربي", c: "تلمسان", t: "عباية العمر", b: "ثالث مرة أطلب نفس العباية لأمي وأختي. القماش ما يتجعّد والسواد فاحم حتى بعد الغسيل. والتوصيل وصل قبل الموعد!", s: "classic-black-abaya" },
              { n: "فهد العتيبي", c: "تلمسان", t: "الهودي الأثقل والأفخم", b: "جربت هوديات من براندات عالمية، هذا يتفوق عليهم بالدفء والخامة. لبسته في سفرة أوروبا وكان مدفيني تماماً.", s: "iconic-black-hoodie" },
              { n: "لينا أحمد", c: "تلمسان", t: "قطعة كوتور", b: "المعطف أفخم من الصور بكثير. البطانة نظيفة والخامة دافئة فعلاً. في الزواج الكل سألني من وين!", s: "camel-coat-luxe" },
            ].map((r, i) => (
              <Reveal key={r.n} delay={(i + 1) as 1 | 2 | 3}>
                <figure className="flex h-full flex-col rounded-[24px] bg-white p-6 shadow-[0_8px_30px_rgba(20,16,12,0.06)] ring-1 ring-ink-950/5">
                  <Stars value={5} />
                  <blockquote className="mt-3 text-[14px] leading-7 font-bold text-ink-950">“{r.t}”</blockquote>
                  <p className="mt-2 flex-1 text-[13.5px] leading-7 text-ink-500">{r.b}</p>
                  <figcaption className="mt-5 flex items-center gap-3 border-t border-ink-950/8 pt-4">
                    <span className="grid h-11 w-11 place-items-center rounded-full bg-ink-950 text-[14px] font-bold text-gold-400">{r.n[0]}</span>
                    <span>
                      <span className="block text-[13px] font-bold">{r.n} <span className="font-normal text-emerald-700">✓ مشتري موثّق</span></span>
                      <span className="block text-[11.5px] text-ink-400">{r.c}</span>
                    </span>
                    <HeartHandshake size={18} className="mr-auto text-gold-600" />
                  </figcaption>
                </figure>
              </Reveal>
            ))}
          </div>
          {/* rating strip */}
          <Reveal>
            <div className="mt-8 flex flex-wrap items-center justify-center gap-x-8 gap-y-3 rounded-[24px] bg-ink-950 px-8 py-5 text-sand-100">
              <span className="flex items-center gap-2 text-[13px]"><Star size={15} className="text-gold-400" fill="currentColor" /> 4.8 متوسط التقييم</span>
              <span className="hidden h-5 w-px bg-white/15 sm:block" />
              <span className="text-[13px]">+2,400 تقييم موثّق</span>
              <span className="hidden h-5 w-px bg-white/15 sm:block" />
              <span className="text-[13px]">98% يوصون بنا لأصدقائهم</span>
            </div>
          </Reveal>
        </div>
      </section>

      {/* CTA */}
      <section className="mx-auto max-w-7xl px-4 pt-20 md:px-8">
        <Reveal>
          <div className="relative overflow-hidden rounded-[32px] bg-gradient-to-l from-gold-600 via-gold-500 to-gold-400 p-8 text-ink-950 md:p-14">
            <div className="pointer-events-none absolute -top-20 -left-20 h-64 w-64 rounded-full bg-white/25 blur-[80px]" />
            <div className="relative flex flex-col items-start justify-between gap-6 md:flex-row md:items-center">
              <div>
                <p className="font-latin text-[11px] font-bold tracking-[0.3em]">FIRST ORDER — 15% OFF</p>
                <h3 className="font-display mt-2 text-3xl font-bold md:text-5xl">أهلاً بك في عائلة ATN+</h3>
                <p className="mt-3 max-w-md text-[14px] leading-7 font-medium text-ink-900/75">استخدم كود <b className="rounded-lg bg-ink-950 px-2.5 py-1 font-latin text-[13px] text-gold-300">DZ15</b> واحصل على خصم 15% على أول طلب + شحن سريع.</p>
              </div>
              <Link href="/shop" className="group flex shrink-0 items-center gap-2 rounded-full bg-ink-950 px-9 py-4.5 text-[14px] font-bold text-sand-100 shadow-2xl transition-transform hover:scale-[1.03]">
                ابدأ التسوق الآن <ArrowLeft size={17} className="transition-transform group-hover:-translate-x-1" />
              </Link>
            </div>
          </div>
        </Reveal>
      </section>
    </main>
  );
}
