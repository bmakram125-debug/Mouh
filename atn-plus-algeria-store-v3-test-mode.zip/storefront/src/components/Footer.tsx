"use client";

import Link from "next/link";
import { Camera, AtSign, MessageCircle, CreditCard, Truck, ShieldCheck, RotateCcw } from "lucide-react";

export default function Footer() {
  return (
    <footer className="mt-24 bg-ink-950 text-sand-100">
      {/* perks */}
      <div className="border-b border-white/10">
        <div className="mx-auto grid max-w-7xl grid-cols-2 gap-6 px-4 py-10 md:grid-cols-4 md:px-8">
          {[
            { icon: Truck, t: "شحن سريع", d: "2-4 أيام لجميع المدن" },
            { icon: RotateCcw, t: "إرجاع مجاني", d: "خلال 14 يوم بدون أسئلة" },
            { icon: ShieldCheck, t: "دفع آمن", d: "مدى، فيزا، آبل باي" },
            { icon: CreditCard, t: "تقسيط تابي", d: "قسّطها على 4 دفعات" },
          ].map((f) => (
            <div key={f.t} className="flex items-start gap-3">
              <span className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl bg-white/8 ring-1 ring-white/10">
                <f.icon size={19} className="text-gold-400" />
              </span>
              <span>
                <span className="block text-[14px] font-bold">{f.t}</span>
                <span className="block text-[12px] text-white/55">{f.d}</span>
              </span>
            </div>
          ))}
        </div>
      </div>

      <div className="mx-auto grid max-w-7xl gap-10 px-4 py-14 md:grid-cols-4 md:px-8">
        <div>
          <div className="flex items-center gap-3">
            <span className="grid h-12 w-12 place-items-center rounded-2xl bg-sand-100 text-ink-950">
              <span className="font-latin text-[16px] font-bold">
                atn<span className="text-gold-600">+</span>
              </span>
            </span>
            <span>
              <span className="font-latin block text-lg font-bold">ATN+</span>
              <span className="block text-[12px] text-white/55">أزياء عربية بروح عالمية</span>
            </span>
          </div>
          <p className="mt-5 max-w-xs text-[13.5px] leading-7 text-white/60">
            علامة سعودية وُلدت من حب التفاصيل. نصمم قطعاً محتشمة وعصرية بجودة كوتور وأسعار عادلة — من العباية اليومية إلى معطف المناسبات.
          </p>
          <div className="mt-5 flex gap-2">
            {[Camera, AtSign, MessageCircle].map((Icon, i) => (
              <a key={i} href="#" className="grid h-10 w-10 place-items-center rounded-full bg-white/8 ring-1 ring-white/10 transition-colors hover:bg-gold-500 hover:text-ink-950">
                <Icon size={17} />
              </a>
            ))}
          </div>
        </div>

        <div>
          <h4 className="text-[14px] font-bold text-gold-300">تسوّق</h4>
          <ul className="mt-4 space-y-3 text-[13.5px] text-white/65">
            <li><Link href="/shop" className="hover:text-white">كل المنتجات</Link></li>
            <li><Link href="/shop?collection=essentials" className="hover:text-white">الأساسيات</Link></li>
            <li><Link href="/shop?collection=modest" className="hover:text-white">العبايات والفساتين</Link></li>
            <li><Link href="/shop?collection=street" className="hover:text-white">الستريت وير</Link></li>
            <li><Link href="/shop?collection=winter" className="hover:text-white">تشكيلة الشتاء</Link></li>
          </ul>
        </div>

        <div>
          <h4 className="text-[14px] font-bold text-gold-300">مساعدة</h4>
          <ul className="mt-4 space-y-3 text-[13.5px] text-white/65">
            <li><Link href="/checkout" className="hover:text-white">تتبع الطلب</Link></li>
            <li><Link href="/shop" className="hover:text-white">دليل المقاسات</Link></li>
            <li><Link href="/shop" className="hover:text-white">سياسة الإرجاع</Link></li>
            <li><Link href="/shop" className="hover:text-white">الشحن والتوصيل</Link></li>
            <li><Link href="/checkout" className="hover:text-white">تواصل معنا</Link></li>
          </ul>
        </div>

        <div>
          <h4 className="text-[14px] font-bold text-gold-300">النشرة البريدية</h4>
          <p className="mt-4 text-[13px] leading-6 text-white/60">خصم 15% على أول طلب عند الاشتراك. جديدنا يوصلك أولاً.</p>
          <form className="mt-4 flex overflow-hidden rounded-2xl bg-white/8 ring-1 ring-white/12 focus-within:ring-gold-500" onSubmit={(e) => e.preventDefault()}>
            <input placeholder="بريدك الإلكتروني" className="w-full bg-transparent px-4 py-3.5 text-[13px] text-white outline-none placeholder:text-white/35" />
            <button className="shrink-0 bg-gold-500 px-5 text-[13px] font-bold text-ink-950 transition-colors hover:bg-gold-400">اشترك</button>
          </form>
          <p className="mt-3 text-[11px] text-white/35">بالاشتراك أنت توافق على سياسة الخصوصية.</p>
        </div>
      </div>

      <div className="border-t border-white/10">
        <div className="mx-auto flex max-w-7xl flex-col items-center justify-between gap-3 px-4 py-6 text-[12px] text-white/40 md:flex-row md:px-8">
          <p>© 2026 ATN+ — جميع الحقوق محفوظة. صُنع بحب في الجزائر.</p>
          <p className="font-latin tracking-[0.25em] text-white/30">ATN+ • MODEST • STREET • ESSENTIALS</p>
        </div>
      </div>
    </footer>
  );
}
