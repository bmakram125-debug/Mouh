"use client";

import { useState } from "react";
import { ThumbsUp, BadgeCheck, PenLine, Star } from "lucide-react";
import { Stars } from "./ui";
import { cn } from "@/lib/format";

export type ReviewItem = {
  id: string;
  author: string;
  city: string;
  rating: number;
  title: string;
  body: string;
  helpful: number;
  verified: boolean;
  createdAt: string | Date;
};

export default function Reviews({ productSlug, initial, avg }: { productSlug: string; initial: ReviewItem[]; avg: number }) {
  const [list, setList] = useState(initial);
  const [helped, setHelped] = useState<Set<string>>(new Set());
  const [form, setForm] = useState({ author: "", city: "تلمسان", rating: 5, title: "", body: "" });
  const [sending, setSending] = useState(false);
  const [done, setDone] = useState(false);

  const dist = [5, 4, 3, 2, 1].map((s) => ({
    star: s,
    count: list.filter((r) => r.rating === s).length,
  }));
  const total = Math.max(1, list.length);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.author.trim() || !form.body.trim()) return;
    setSending(true);
    try {
      const res = await fetch("/api/reviews", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ productSlug, ...form }),
      });
      if (res.ok) {
        const j = await res.json();
        setList((prev) => [j.review, ...prev]);
        setDone(true);
        setForm({ author: "", city: "تلمسان", rating: 5, title: "", body: "" });
        setTimeout(() => setDone(false), 4000);
      }
    } finally {
      setSending(false);
    }
  };

  return (
    <div id="reviews" className="mt-16 scroll-mt-28">
      <h2 className="font-display text-3xl font-bold md:text-4xl">آراء عملائنا <span className="text-[16px] font-sans font-medium text-ink-400">({list.length} تقييم)</span></h2>

      <div className="mt-6 grid gap-6 lg:grid-cols-[320px_1fr]">
        {/* summary */}
        <div className="h-fit rounded-[24px] bg-ink-950 p-7 text-sand-100">
          <p className="font-latin text-5xl font-bold">{avg.toFixed(1)}</p>
          <Stars value={avg} className="mt-2 text-gold-400" />
          <p className="mt-2 text-[12.5px] text-white/60">بناءً على {list.length} تقييم موثّق</p>
          <div className="mt-5 space-y-2">
            {dist.map((d) => (
              <div key={d.star} className="flex items-center gap-2 text-[12px]">
                <span className="w-6 font-bold" dir="ltr">{d.star}★</span>
                <div className="h-2 flex-1 overflow-hidden rounded-full bg-white/12">
                  <div className="h-full rounded-full bg-gold-400" style={{ width: `${(d.count / total) * 100}%` }} />
                </div>
                <span className="w-7 text-white/55">{d.count}</span>
              </div>
            ))}
          </div>
          <p className="mt-5 rounded-2xl bg-white/8 p-3.5 text-[12px] leading-6 text-white/65 ring-1 ring-white/10">
            98% من العملاء يوصون بهذا المنتج لأصدقائهم.
          </p>
        </div>

        {/* list + form */}
        <div>
          <div className="space-y-4">
            {list.map((r) => (
              <article key={r.id} className="rounded-[22px] bg-white p-6 ring-1 ring-ink-950/8">
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <span className="grid h-11 w-11 place-items-center rounded-full bg-sand-200 text-[15px] font-bold text-ink-900">{r.author[0]}</span>
                    <div>
                      <p className="flex items-center gap-1.5 text-[13.5px] font-bold">
                        {r.author}
                        {r.verified && <span className="flex items-center gap-1 rounded-full bg-emerald-50 px-2 py-0.5 text-[10.5px] font-bold text-emerald-700"><BadgeCheck size={12} /> مشتري موثّق</span>}
                      </p>
                      <p className="text-[11.5px] text-ink-400">{r.city} • {new Date(r.createdAt).toLocaleDateString("ar-SA")}</p>
                    </div>
                  </div>
                  <Stars value={r.rating} />
                </div>
                <p className="mt-3 text-[14px] font-bold">{r.title}</p>
                <p className="mt-1 text-[13.5px] leading-7 text-ink-500">{r.body}</p>
                <button
                  onClick={() => {
                    if (helped.has(r.id)) return;
                    setHelped((p) => new Set(p).add(r.id));
                    setList((prev) => prev.map((x) => (x.id === r.id ? { ...x, helpful: x.helpful + 1 } : x)));
                  }}
                  className={cn(
                    "mt-3 flex items-center gap-1.5 rounded-full px-3.5 py-2 text-[12px] font-bold ring-1 transition-all",
                    helped.has(r.id) ? "bg-ink-950 text-sand-100 ring-ink-950" : "bg-sand-100 text-ink-500 ring-ink-950/10 hover:ring-ink-950/30",
                  )}
                >
                  <ThumbsUp size={13} /> مفيد ({r.helpful})
                </button>
              </article>
            ))}
          </div>

          {/* form */}
          <form onSubmit={submit} className="mt-6 rounded-[24px] bg-white p-6 ring-1 ring-ink-950/8 md:p-8">
            <h3 className="flex items-center gap-2 text-[16px] font-bold"><PenLine size={17} className="text-gold-600" /> شاركنا رأيك</h3>
            {done && <p className="mt-3 rounded-2xl bg-emerald-50 px-4 py-3 text-[13px] font-bold text-emerald-700">شكراً! تم نشر تقييمك بنجاح ✓</p>}
            <div className="mt-4 grid gap-3 md:grid-cols-2">
              <input value={form.author} onChange={(e) => setForm({ ...form, author: e.target.value })} placeholder="اسمك الكريم *" className="rounded-2xl bg-sand-100 px-4 py-3.5 text-[13.5px] ring-1 ring-ink-950/8 outline-none focus:ring-ink-950" />
              <select value={form.city} onChange={(e) => setForm({ ...form, city: e.target.value })} className="rounded-2xl bg-sand-100 px-4 py-3.5 text-[13.5px] ring-1 ring-ink-950/8 outline-none">
                {["تلمسان", "الجزائر", "وهران", "قسنطينة", "عنابة", "سطيف", "البليدة", "بجاية", "سيدي بلعباس", "مستغانم", "أخرى"].map((c) => <option key={c}>{c}</option>)}
              </select>
            </div>
            <div className="mt-3 flex items-center gap-2">
              <span className="text-[13px] font-bold">تقييمك:</span>
              <span className="flex gap-1" dir="ltr">
                {[1, 2, 3, 4, 5].map((s) => (
                  <button type="button" key={s} onClick={() => setForm({ ...form, rating: s })} aria-label={`${s} نجوم`}>
                    <Star size={24} className={s <= form.rating ? "text-gold-500" : "text-ink-950/15"} fill="currentColor" strokeWidth={0} />
                  </button>
                ))}
              </span>
            </div>
            <input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} placeholder="عنوان التقييم (مثال: خامة ممتازة)" className="mt-3 w-full rounded-2xl bg-sand-100 px-4 py-3.5 text-[13.5px] ring-1 ring-ink-950/8 outline-none focus:ring-ink-950" />
            <textarea value={form.body} onChange={(e) => setForm({ ...form, body: e.target.value })} placeholder="احكِ لنا عن تجربتك: الخامة، المقاس، التوصيل... *" rows={4} className="mt-3 w-full resize-none rounded-2xl bg-sand-100 px-4 py-3.5 text-[13.5px] ring-1 ring-ink-950/8 outline-none focus:ring-ink-950" />
            <button disabled={sending} className="mt-4 w-full rounded-2xl bg-ink-950 py-4 text-[14px] font-bold text-sand-100 transition-opacity disabled:opacity-50 md:w-auto md:px-10">
              {sending ? "جاري النشر..." : "نشر التقييم"}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}
