"use client";

import { useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import Image from "next/image";
import Link from "next/link";
import { MapPin, CreditCard, ClipboardCheck, ArrowLeft, Lock, Truck, BadgePercent, Check } from "lucide-react";
import { useCart } from "./cart-context";
import { formatPrice, cn } from "@/lib/format";

const cities = ["تلمسان", "الجزائر", "وهران", "قسنطينة", "عنابة", "سطيف", "البليدة", "باتنة", "بجاية", "تيزي وزو", "سيدي بلعباس", "مستغانم", "الشلف", "بسكرة", "الجلفة", "ورقلة", "أدرار", "بشار", "غرداية", "الأغواط", "المدية", "معسكر", "تيارت", "سعيدة", "تبسة", "برج بوعريريج", "جيجل", "سكيكدة", "الطارف", "الوادي", "أم البواقي", "ميلة", "عين تموشنت", "قالمة", "خنشلة", "سوق أهراس", "تيسمسيلت", "عين الدفلى", "النعامة", "البيض", "تمنراست", "إليزي", "تندوف", "تيميمون", "برج باجي مختار", "أولاد جلال", "بني عباس", "إن صالح", "إن قزام", "تقرت", "المغير", "المنيعة", "أخرى"];

export default function CheckoutClient() {
  const { items, subtotal, clear } = useCart();
  const router = useRouter();
  const [step, setStep] = useState(1);
  const [form, setForm] = useState({
    name: "",
    phone: "",
    email: "",
    city: "تلمسان",
    address: "",
    notes: "",
    shipping: "standard",
    payment: "cod",
  });
  const [coupon, setCoupon] = useState("");
  const [couponApplied, setCouponApplied] = useState(0);
  const [error, setError] = useState("");
  const [placing, setPlacing] = useState(false);

  const shippingCost = useMemo(() => {
    if (subtotal >= 10000) return 0;
    return form.shipping === "express" ? 1500 : 800;
  }, [subtotal, form.shipping]);

  const discount = useMemo(() => {
    if (couponApplied > 0) return Math.round(subtotal * couponApplied);
    return 0;
  }, [subtotal, couponApplied]);

  const total = Math.max(0, subtotal - discount + shippingCost);

  const applyCoupon = () => {
    const c = coupon.trim().toUpperCase();
    if (c === "DZ15") setCouponApplied(0.15);
    else if (c === "DZ10") setCouponApplied(0.1);
    else setCouponApplied(0);
  };

  const validStep1 = form.name.trim().length >= 3 && /^[0-9+\s]{9,14}$/.test(form.phone.trim()) && form.address.trim().length >= 8;

  const placeOrder = async () => {
    if (!validStep1) {
      setStep(1);
      setError("فضلاً أكمل بيانات التوصيل بشكل صحيح (الاسم، الجوال، العنوان).");
      return;
    }
    if (items.length === 0) {
      setError("سلتك فارغة.");
      return;
    }
    setError("");
    setPlacing(true);
    try {
      const res = await fetch("/api/orders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          customerName: form.name,
          phone: form.phone,
          email: form.email,
          city: form.city,
          address: form.address,
          notes: form.notes,
          paymentMethod: form.payment,
          shippingMethod: form.shipping,
          coupon: couponApplied > 0 ? coupon.trim().toUpperCase() : undefined,
          items: items.map((i) => ({ slug: i.slug, name: i.name, image: i.image, price: i.price, qty: i.qty, size: i.size, color: i.color })),
        }),
      });
      const j = await res.json();
      if (!res.ok) throw new Error(j.error ?? "تعذر إتمام الطلب");
      if (j.paymentRequired && j.checkoutUrl) {
        clear();
        window.location.href = j.checkoutUrl;
        return;
      }
      clear();
      router.push(`/success?order=${j.orderNumber}`);
    } catch (e) {
      setError(e instanceof Error ? e.message : "حدث خطأ، حاول مجدداً");
    } finally {
      setPlacing(false);
    }
  };

  if (items.length === 0) {
    return (
      <div className="mx-auto max-w-lg rounded-[28px] bg-white p-10 text-center ring-1 ring-ink-950/8">
        <p className="text-5xl">🛒</p>
        <h2 className="font-display mt-4 text-3xl font-bold">سلتك فارغة</h2>
        <p className="mt-2 text-[14px] leading-7 text-ink-500">لا يمكنك إتمام الطلب بدون منتجات. اكتشف تشكيلاتنا وأضف ما يعجبك.</p>
        <Link href="/shop" className="mt-6 inline-flex rounded-full bg-ink-950 px-8 py-3.5 text-[14px] font-bold text-sand-100">
          العودة للمتجر
        </Link>
      </div>
    );
  }

  const steps = [
    { n: 1, t: "التوصيل", icon: MapPin },
    { n: 2, t: "الشحن والدفع", icon: CreditCard },
    { n: 3, t: "المراجعة", icon: ClipboardCheck },
  ];

  return (
    <div className="grid gap-8 lg:grid-cols-[1fr_380px]">
      {/* main */}
      <div>
        {/* stepper */}
        <div className="flex items-center gap-2">
          {steps.map((s, i) => (
            <div key={s.n} className="flex flex-1 items-center gap-2">
              <button
                onClick={() => s.n < step && setStep(s.n)}
                className={cn(
                  "flex flex-1 items-center justify-center gap-2 rounded-2xl px-3 py-3 text-[12.5px] font-bold ring-1 transition-all",
                  step === s.n ? "bg-ink-950 text-sand-100 ring-ink-950" : step > s.n ? "bg-emerald-700 text-white ring-emerald-700" : "bg-white text-ink-400 ring-ink-950/10",
                )}
              >
                {step > s.n ? <Check size={15} /> : <s.icon size={15} />}
                <span className="hidden sm:inline">{s.t}</span>
                <span className="sm:hidden">{s.n}</span>
              </button>
              {i < 2 && <span className="h-px w-3 bg-ink-950/15" />}
            </div>
          ))}
        </div>

        {error && <p className="mt-4 rounded-2xl bg-red-50 px-4 py-3 text-[13px] font-bold text-red-700 ring-1 ring-red-200">{error}</p>}

        {/* STEP 1 */}
        {step === 1 && (
          <div className="mt-5 rounded-[24px] bg-white p-6 ring-1 ring-ink-950/8 md:p-8">
            <h3 className="flex items-center gap-2 text-[16px] font-bold"><MapPin size={17} className="text-gold-600" /> عنوان التوصيل</h3>
            <div className="mt-5 grid gap-3.5 md:grid-cols-2">
              <div className="md:col-span-1">
                <label className="text-[12.5px] font-bold">الاسم الكامل *</label>
                <input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="مثال: نورة عبدالله" className="mt-1.5 w-full rounded-2xl bg-sand-100 px-4 py-3.5 text-[13.5px] ring-1 ring-ink-950/8 outline-none focus:ring-ink-950" />
              </div>
              <div>
                <label className="text-[12.5px] font-bold">رقم الجوال *</label>
                <input value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} placeholder="05/06/07xxxxxxxx" dir="ltr" className="mt-1.5 w-full rounded-2xl bg-sand-100 px-4 py-3.5 text-[13.5px] ring-1 ring-ink-950/8 outline-none focus:ring-ink-950 text-right" />
              </div>
              <div className="md:col-span-2">
                <label className="text-[12.5px] font-bold">البريد الإلكتروني (اختياري)</label>
                <input value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} placeholder="you@email.com" dir="ltr" className="mt-1.5 w-full rounded-2xl bg-sand-100 px-4 py-3.5 text-[13.5px] ring-1 ring-ink-950/8 outline-none focus:ring-ink-950 text-right" />
              </div>
              <div>
                <label className="text-[12.5px] font-bold">المدينة *</label>
                <select value={form.city} onChange={(e) => setForm({ ...form, city: e.target.value })} className="mt-1.5 w-full rounded-2xl bg-sand-100 px-4 py-3.5 text-[13.5px] ring-1 ring-ink-950/8 outline-none">
                  {cities.map((c) => <option key={c}>{c}</option>)}
                </select>
              </div>
              <div>
                <label className="text-[12.5px] font-bold">الحي / الرمز البريدي</label>
                <input value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} placeholder="الحي، الشارع، الرمز البريدي..." className="mt-1.5 w-full rounded-2xl bg-sand-100 px-4 py-3.5 text-[13.5px] ring-1 ring-ink-950/8 outline-none focus:ring-ink-950" />
              </div>
              <div className="md:col-span-2">
                <label className="text-[12.5px] font-bold">العنوان التفصيلي *</label>
                <textarea value={form.address} onChange={(e) => setForm({ ...form, address: e.target.value })} rows={3} placeholder="اسم الشارع، رقم المبنى، الشقة، علامة مميزة..." className="mt-1.5 w-full resize-none rounded-2xl bg-sand-100 px-4 py-3.5 text-[13.5px] ring-1 ring-ink-950/8 outline-none focus:ring-ink-950" />
              </div>
            </div>
            <button
              onClick={() => (validStep1 ? (setError(""), setStep(2)) : setError("فضلاً أكمل الحقول المطلوبة: الاسم (3 أحرف+)، جوال صحيح، وعنوان واضح."))}
              className="mt-6 flex w-full items-center justify-center gap-2 rounded-2xl bg-ink-950 py-4 text-[14px] font-bold text-sand-100"
            >
              متابعة للشحن والدفع <ArrowLeft size={16} />
            </button>
          </div>
        )}

        {/* STEP 2 */}
        {step === 2 && (
          <div className="mt-5 space-y-5">
            <div className="rounded-[24px] bg-white p-6 ring-1 ring-ink-950/8 md:p-8">
              <h3 className="flex items-center gap-2 text-[16px] font-bold"><Truck size={17} className="text-gold-600" /> طريقة الشحن</h3>
              <div className="mt-4 grid gap-3 md:grid-cols-2">
                {[
                  { id: "standard", t: "شحن عادي", d: "2-4 أيام عمل", p: subtotal >= 10000 ? 0 : 25 },
                  { id: "express", t: "شحن سريع", d: "24-48 ساعة", p: subtotal >= 10000 ? 500 : 1500 },
                ].map((o) => (
                  <button
                    key={o.id}
                    onClick={() => setForm({ ...form, shipping: o.id })}
                    className={cn(
                      "rounded-2xl border-2 p-4 text-right transition-all",
                      form.shipping === o.id ? "border-ink-950 bg-sand-100" : "border-ink-950/10 bg-white hover:border-ink-950/30",
                    )}
                  >
                    <span className="flex items-center justify-between text-[13.5px] font-bold">
                      {o.t}
                      <span className={cn("h-4 w-4 rounded-full ring-2", form.shipping === o.id ? "bg-ink-950 ring-ink-950" : "ring-ink-950/25")} />
                    </span>
                    <span className="mt-1 block text-[12px] text-ink-500">{o.d}</span>
                    <span className="mt-2 block text-[13px] font-bold">{o.p === 0 ? "مجاني 🎉" : formatPrice(o.p)}</span>
                  </button>
                ))}
              </div>
            </div>

            <div className="rounded-[24px] bg-white p-6 ring-1 ring-ink-950/8 md:p-8">
              <h3 className="flex items-center gap-2 text-[16px] font-bold"><CreditCard size={17} className="text-gold-600" /> طريقة الدفع</h3>
              <div className="mt-4 grid gap-3">
                {[
                  { id: "cod", t: "الدفع عند الاستلام", d: "ادفع عند وصول طلبك عبر المندوب", e: "💵" },
                  { id: "online", t: "الدفع الإلكتروني CIB / EDAHABIA", d: "تحويل آمن إلى بوابة Chargily Pay", e: "💳" },
                ].map((o) => (
                  <button
                    key={o.id}
                    onClick={() => setForm({ ...form, payment: o.id })}
                    className={cn(
                      "flex items-center gap-3 rounded-2xl border-2 p-4 text-right transition-all",
                      form.payment === o.id ? "border-ink-950 bg-sand-100" : "border-ink-950/10 bg-white hover:border-ink-950/30",
                    )}
                  >
                    <span className="text-2xl">{o.e}</span>
                    <span className="flex-1">
                      <span className="block text-[13.5px] font-bold">{o.t}</span>
                      <span className="block text-[12px] text-ink-500">{o.d}</span>
                    </span>
                    <span className={cn("h-4 w-4 shrink-0 rounded-full ring-2", form.payment === o.id ? "bg-ink-950 ring-ink-950" : "ring-ink-950/25")} />
                  </button>
                ))}
              </div>
              <div className="mt-5 flex gap-3">
                <button onClick={() => setStep(1)} className="rounded-2xl bg-sand-100 px-6 py-4 text-[13.5px] font-bold ring-1 ring-ink-950/10">رجوع</button>
                <button onClick={() => setStep(3)} className="flex flex-1 items-center justify-center gap-2 rounded-2xl bg-ink-950 py-4 text-[14px] font-bold text-sand-100">
                  مراجعة الطلب <ArrowLeft size={16} />
                </button>
              </div>
            </div>
          </div>
        )}

        {/* STEP 3 */}
        {step === 3 && (
          <div className="mt-5 rounded-[24px] bg-white p-6 ring-1 ring-ink-950/8 md:p-8">
            <h3 className="flex items-center gap-2 text-[16px] font-bold"><ClipboardCheck size={17} className="text-gold-600" /> مراجعة وتأكيد</h3>
            <div className="mt-4 space-y-3">
              {items.map((i) => (
                <div key={i.key} className="flex items-center gap-3 rounded-2xl bg-sand-100 p-3 ring-1 ring-ink-950/5">
                  <span className="relative h-16 w-14 shrink-0 overflow-hidden rounded-xl">
                    <Image src={i.image} alt={i.name} fill className="object-cover" sizes="56px" />
                    <span className="absolute -top-0 -left-0 rounded-br-xl bg-ink-950 px-1.5 text-[11px] font-bold text-white">×{i.qty}</span>
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className="block truncate text-[13px] font-bold">{i.name}</span>
                    <span className="block text-[11.5px] text-ink-400">{i.color} • {i.size}</span>
                  </span>
                  <b className="text-[13px]">{formatPrice(i.price * i.qty)}</b>
                </div>
              ))}
            </div>
            <div className="mt-4 rounded-2xl bg-sand-100 p-4 text-[13px] leading-7 ring-1 ring-ink-950/5">
              <p><b>التوصيل:</b> {form.name} — {form.phone}</p>
              <p><b>العنوان:</b> {form.city}، {form.address}</p>
              <p><b>الدفع:</b> {form.payment === "online" ? "CIB / EDAHABIA" : "الدفع عند الاستلام"} • <b>الشحن:</b> {form.shipping === "express" ? "سريع" : "عادي"}</p>
              <button onClick={() => setStep(1)} className="mt-1 text-[12px] font-bold text-gold-700 underline underline-offset-4">تعديل البيانات</button>
            </div>
            <button
              onClick={placeOrder}
              disabled={placing}
              className="mt-5 flex w-full items-center justify-center gap-2 rounded-2xl bg-emerald-700 py-4.5 text-[15px] font-bold text-white shadow-xl transition-all hover:bg-emerald-800 disabled:opacity-60"
            >
              <Lock size={16} /> {placing ? "جاري معالجة الطلب..." : form.payment === "online" ? `الانتقال للدفع — ${formatPrice(total)}` : `تأكيد الطلب — ${formatPrice(total)}`}
            </button>
            <p className="mt-3 text-center text-[11.5px] text-ink-400">بالضغط على تأكيد الطلب أنت توافق على شروط الاستخدام وسياسة الإرجاع.</p>
          </div>
        )}
      </div>

      {/* summary */}
      <aside className="h-fit lg:sticky lg:top-28">
        <div className="rounded-[24px] bg-ink-950 p-6 text-sand-100">
          <h3 className="text-[15px] font-bold">ملخص الطلب ({items.length})</h3>
          <div className="mt-4 max-h-64 space-y-3 overflow-y-auto">
            {items.map((i) => (
              <div key={i.key} className="flex items-center gap-3">
                <span className="relative h-14 w-12 shrink-0 overflow-hidden rounded-xl">
                  <Image src={i.image} alt="" fill className="object-cover" sizes="48px" />
                </span>
                <span className="min-w-0 flex-1">
                  <span className="block truncate text-[12.5px] font-bold">{i.name}</span>
                  <span className="block text-[11px] text-white/55">×{i.qty} • {i.size}</span>
                </span>
                <span className="text-[12.5px] font-bold">{formatPrice(i.price * i.qty)}</span>
              </div>
            ))}
          </div>
          {/* coupon */}
          <div className="mt-5">
            <div className="flex overflow-hidden rounded-2xl bg-white/8 ring-1 ring-white/12">
              <input value={coupon} onChange={(e) => setCoupon(e.target.value)} placeholder="كود الخصم (جرّب DZ15)" className="w-full bg-transparent px-4 py-3 text-[12.5px] outline-none placeholder:text-white/35 font-latin" dir="ltr" />
              <button onClick={applyCoupon} className="flex shrink-0 items-center gap-1 bg-gold-500 px-4 text-[12.5px] font-bold text-ink-950">
                <BadgePercent size={14} /> تطبيق
              </button>
            </div>
            {couponApplied > 0 && <p className="mt-2 text-[12px] font-bold text-emerald-300">✓ تم تطبيق خصم {Math.round(couponApplied * 100)}%</p>}
            {coupon && couponApplied === 0 && coupon.length > 3 && <p className="mt-2 text-[12px] text-white/50">الكود غير صالح — جرّب DZ15</p>}
          </div>
          <div className="mt-5 space-y-2 border-t border-white/10 pt-4 text-[13px]">
            <div className="flex justify-between text-white/70"><span>المجموع الفرعي</span><span>{formatPrice(subtotal)}</span></div>
            {discount > 0 && <div className="flex justify-between text-emerald-300"><span>خصم الكوبون</span><span>-{formatPrice(discount)}</span></div>}
            <div className="flex justify-between text-white/70"><span>الشحن</span><span>{shippingCost === 0 ? "مجاني 🎉" : formatPrice(shippingCost)}</span></div>
            <div className="flex justify-between border-t border-white/10 pt-3 text-[16px] font-bold"><span>الإجمالي</span><span className="text-gold-300">{formatPrice(total)}</span></div>
          </div>
          <p className="mt-4 flex items-center justify-center gap-1.5 text-[11px] text-white/45"><Lock size={12} /> دفع آمن ومشفر 100%</p>
        </div>
        <Link href="/shop" className="mt-3 block text-center text-[12.5px] font-bold text-ink-500 hover:text-ink-950">← مواصلة التسوق</Link>
      </aside>
    </div>
  );
}
