"use client";

import Link from "next/link";
import Image from "next/image";
import { Heart, Plus } from "lucide-react";
import { useState } from "react";
import { Stars } from "./ui";
import { discountPct, formatPrice, cn } from "@/lib/format";
import { useCart } from "./cart-context";

export type CardProduct = {
  slug: string;
  name: string;
  nameEn: string;
  price: number;
  compareAtPrice: number | null;
  category: string;
  images: string[];
  rating: number;
  reviewCount: number;
  badge: string | null;
  isNew: boolean;
  colors: { name: string; hex: string }[];
  sizes: string[];
};

export default function ProductCard({ p, index = 0 }: { p: CardProduct; index?: number }) {
  const { addItem } = useCart();
  const [liked, setLiked] = useState(false);
  const pct = discountPct(p.price, p.compareAtPrice);

  return (
    <div
      className="group relative flex flex-col overflow-hidden rounded-[22px] bg-white shadow-[0_2px_20px_rgba(20,16,12,0.06)] ring-1 ring-ink-950/5 transition-all duration-500 hover:-translate-y-1.5 hover:shadow-[0_24px_50px_rgba(20,16,12,0.14)]"
      style={{ animationDelay: `${index * 60}ms` }}
    >
      <Link href={`/product/${p.slug}`} className="card-zoom relative block aspect-[3/4] overflow-hidden bg-sand-200">
        <Image
          src={p.images[0]}
          alt={p.name}
          fill
          sizes="(max-width:768px) 50vw, (max-width:1200px) 33vw, 25vw"
          className="object-cover"
          loading="lazy"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-ink-950/25 via-transparent to-transparent opacity-0 transition-opacity duration-500 group-hover:opacity-100" />
        {/* badges */}
        <div className="absolute top-3 right-3 flex flex-col items-end gap-2">
          {p.badge && (
            <span className="shine rounded-full bg-ink-950 px-3 py-1.5 text-[11px] font-bold text-sand-100 shadow-lg">{p.badge}</span>
          )}
          {pct && <span className="rounded-full bg-clay-500 px-3 py-1.5 text-[11px] font-bold text-white shadow-lg">-{pct}%</span>}
          {p.isNew && !p.badge && (
            <span className="rounded-full bg-gold-500 px-3 py-1.5 text-[11px] font-bold text-ink-950 shadow-lg">جديد</span>
          )}
        </div>
        <button
          aria-label="مفضلة"
          onClick={(e) => {
            e.preventDefault();
            setLiked((v) => !v);
          }}
          className={cn(
            "absolute top-3 left-3 grid h-9 w-9 place-items-center rounded-full backdrop-blur-md transition-all",
            liked ? "bg-ink-950 text-rose-400" : "bg-white/80 text-ink-900 hover:bg-white",
          )}
        >
          <Heart size={16} fill={liked ? "currentColor" : "none"} />
        </button>
        {/* quick add */}
        <div className="absolute inset-x-3 bottom-3 translate-y-3 opacity-0 transition-all duration-500 group-hover:translate-y-0 group-hover:opacity-100">
          <button
            onClick={(e) => {
              e.preventDefault();
              addItem(
                {
                  slug: p.slug,
                  name: p.name,
                  nameEn: p.nameEn,
                  image: p.images[0],
                  price: p.price,
                  size: p.sizes[0] ?? "M",
                  color: p.colors[0]?.name ?? "—",
                },
                1,
              );
            }}
            className="flex w-full items-center justify-center gap-2 rounded-2xl bg-ink-950/90 py-3 text-[13px] font-bold text-sand-100 backdrop-blur-md transition-colors hover:bg-ink-950"
          >
            <Plus size={15} /> إضافة سريعة للسلة
          </button>
        </div>
      </Link>

      <div className="flex flex-1 flex-col gap-1.5 p-4">
        <p className="text-[11px] font-medium tracking-wide text-ink-400">{p.category}</p>
        <Link href={`/product/${p.slug}`} className="leading-7 font-bold text-ink-950 transition-colors hover:text-gold-700">
          {p.name}
        </Link>
        <div className="flex items-center gap-2">
          <Stars value={p.rating} />
          <span className="text-[11px] text-ink-400">({p.reviewCount})</span>
        </div>
        <div className="mt-1 flex items-center justify-between">
          <div className="flex items-baseline gap-2">
            <span className="text-[17px] font-bold text-ink-950">{formatPrice(p.price)}</span>
            {p.compareAtPrice && p.compareAtPrice > p.price && (
              <span className="text-[13px] text-ink-400 line-through">{formatPrice(p.compareAtPrice)}</span>
            )}
          </div>
          <div className="flex items-center gap-1" dir="ltr">
            {p.colors.slice(0, 3).map((c) => (
              <span key={c.name} title={c.name} className="h-4 w-4 rounded-full ring-1 ring-ink-950/20" style={{ background: c.hex }} />
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
