"use client";

import { useState } from "react";
import Image from "next/image";
import Link from "next/link";
import { Minus, Plus, ShoppingBag, Heart, Truck, RotateCcw, ShieldCheck, Ruler, Check, ChevronLeft } from "lucide-react";
import { Stars } from "./ui";
import { discountPct, formatPrice, cn } from "@/lib/format";
import { useCart } from "./cart-context";
import ProductCard, { type CardProduct } from "./ProductCard";

type DetailProduct = {
  slug: string;
  name: string;
  nameEn: string;
  description: string;
  details: string;
  price: number;
  compareAtPrice: number | null;
  category: string;
  images: string[];
  colors: { name: string; hex: string }[];
  sizes: string[];
  fabric: string;
  stock: number;
  rating: number;
  reviewCount: number;
  soldCount: number;
  badge: string | null;
  isNew: boolean;
};

export default function ProductDetail({
  product,
  related,
}: {
  product: DetailProduct;
  related: CardProduct[];
}) {
  const { addItem } = useCart();
  const [img, setImg] = useState(0);
  const [size, setSize] = useState(product.sizes[0] ?? "M");
  const [color, setColor] = useState(product.colors[0]?.name ?? "");
  const [qty, setQty] = useState(1);
  const [liked, setLiked] = useState(false);
  const [tab, setTab] = useState<"desc" | "details" | "ship">("desc");
  const [added, setAdded] = useState(false);
  const pct = discountPct(product.price, product.compareAtPrice);

  const handleAdd = () => {
    addItem(
      {
        slug: product.slug,
        name: product.name,
        nameEn: product.nameEn,
        image: product.images[0],
        price: product.price,
        size,
        color,
      },
      qty,
    );
    setAdded(true);
    setTimeout(() => setAdded(false), 2200);
  };

  return (
    <div>
      {/* breadcrumb */}
      <nav className="flex items-center gap-1.5 text-[12.5px] text-ink-400">
        <Link href="/" className="hover:text-ink-950">الرئيسية</Link>
        <ChevronLeft size={13} />
        <Link href="/shop" className="hover:text-ink-950">المتجر</Link>
        <ChevronLeft size={13} />
        <span className="font-bold text-ink-900">{product.name}</span>
      </nav>

      <div className="mt-6 grid gap-10 lg:grid-cols-2">
        {/* gallery */}
        <div>
          <div className="relative aspect-[3/4] overflow-hidden rounded-[28px] bg-white shadow-xl ring-1 ring-ink-950/8">
            <Image
              key={img}
              src={product.images[img]}
              alt={product.name}
              fill
              className="animate-fade-up object-cover"
              priority
              sizes="(max-width:1024px) 100vw, 50vw"
            />
            <div className="absolute top-4 right-4 flex flex-col items-end gap-2">
              {product.badge && <span className="shine rounded-full bg-ink-950 px-4 py-2 text-[12px] font-bold text-sand-100 shadow-lg">{product.badge}</span>}
              {pct && <span className="rounded-full bg-clay-500 px-4 py-2 text-[12px] font-bold text-white shadow-lg">خصم {pct}%</span>}
            </div>
            <button
              onClick={() => setLiked((v) => !v)}
              aria-label="مفضلة"
              className={cn(
                "absolute top-4 left-4 grid h-11 w-11 place-items-center rounded-full backdrop-blur-md transition-all",
                liked ? "bg-ink-950 text-rose-400" : "bg-white/85 text-ink-900",
              )}
            >
              <Heart size={18} fill={liked ? "currentColor" : "none"} />
            </button>
            {product.stock < 60 && (
              <span className="absolute bottom-4 right-4 rounded-full bg-red-600/90 px-4 py-2 text-[12px] font-bold text-white backdrop-blur-md">
                باقي {product.stock} قطعة فقط — اطلب الآن
              </span>
            )}
          </div>
          <div className="mt-4 grid grid-cols-3 gap-3">
            {product.images.map((src, i) => (
              <button
                key={i}
                onClick={() => setImg(i)}
                className={cn(
                  "relative aspect-[3/4] overflow-hidden rounded-2xl ring-2 transition-all",
                  img === i ? "ring-ink-950" : "opacity-70 ring-transparent hover:opacity-100",
                )}
              >
                <Image src={src} alt="" fill className="object-cover" sizes="160px" />
              </button>
            ))}
          </div>
        </div>

        {/* info */}
        <div>
          <p className="font-latin text-[11px] tracking-[0.3em] text-gold-600 uppercase">{product.category}</p>
          <h1 className="font-display mt-2 text-3xl leading-snug font-bold text-ink-950 md:text-[42px] md:leading-[1.35]">{product.name}</h1>
          <p className="font-latin mt-1 text-[13px] text-ink-400">{product.nameEn}</p>

          <div className="mt-3 flex flex-wrap items-center gap-3">
            <Stars value={product.rating} />
            <b className="text-[14px]">{product.rating.toFixed(1)}</b>
            <a href="#reviews" className="text-[12.5px] text-ink-400 underline underline-offset-4 hover:text-ink-900">
              {product.reviewCount} تقييم • {product.soldCount.toLocaleString("ar-SA")} عملية شراء
            </a>
          </div>

          <div className="mt-5 flex items-baseline gap-3 rounded-[22px] bg-white p-5 ring-1 ring-ink-950/8">
            <span className="text-[30px] font-bold text-ink-950">{formatPrice(product.price)}</span>
            {product.compareAtPrice && product.compareAtPrice > product.price && (
              <>
                <span className="text-[16px] text-ink-400 line-through">{formatPrice(product.compareAtPrice)}</span>
                <span className="rounded-full bg-emerald-100 px-3 py-1 text-[12px] font-bold text-emerald-800">
                  وفّر {formatPrice(product.compareAtPrice - product.price)}
                </span>
              </>
            )}
            <span className="mr-auto text-[11.5px] text-ink-400">شامل الضريبة</span>
          </div>

          {/* colors */}
          <div className="mt-6">
            <p className="text-[13px] font-bold">اللون: <span className="text-gold-700">{color}</span></p>
            <div className="mt-3 flex gap-2.5">
              {product.colors.map((c) => (
                <button
                  key={c.name}
                  title={c.name}
                  onClick={() => setColor(c.name)}
                  className={cn(
                    "grid h-11 w-11 place-items-center rounded-full ring-2 ring-offset-2 ring-offset-sand-100 transition-all",
                    color === c.name ? "ring-ink-950" : "ring-transparent hover:ring-ink-950/30",
                  )}
                  style={{ background: c.hex }}
                >
                  {color === c.name && <Check size={16} className={c.hex === "#FFFFFF" || c.hex === "#F3EDE1" || c.hex === "#F8F3E8" ? "text-ink-950" : "text-white"} />}
                </button>
              ))}
            </div>
          </div>

          {/* sizes */}
          <div className="mt-6">
            <div className="flex items-center justify-between">
              <p className="text-[13px] font-bold">المقاس: <span className="text-gold-700">{size}</span></p>
              <button className="flex items-center gap-1 text-[12px] font-semibold text-ink-400 hover:text-ink-900">
                <Ruler size={14} /> دليل المقاسات
              </button>
            </div>
            <div className="mt-3 flex flex-wrap gap-2">
              {product.sizes.map((s) => (
                <button
                  key={s}
                  onClick={() => setSize(s)}
                  className={cn(
                    "min-w-13 rounded-2xl px-5 py-3 text-[13.5px] font-bold ring-1 transition-all",
                    size === s ? "bg-ink-950 text-sand-100 ring-ink-950 shadow-lg" : "bg-white text-ink-700 ring-ink-950/12 hover:ring-ink-950",
                  )}
                >
                  {s}
                </button>
              ))}
            </div>
          </div>

          {/* qty + add */}
          <div className="mt-7 flex gap-3">
            <div className="flex items-center gap-1 rounded-2xl bg-white p-1.5 ring-1 ring-ink-950/12">
              <button onClick={() => setQty((q) => Math.min(9, q + 1))} className="grid h-11 w-11 place-items-center rounded-xl bg-sand-100 hover:bg-sand-200" aria-label="زيادة"><Plus size={16} /></button>
              <span className="w-10 text-center text-[16px] font-bold">{qty}</span>
              <button onClick={() => setQty((q) => Math.max(1, q - 1))} className="grid h-11 w-11 place-items-center rounded-xl bg-sand-100 hover:bg-sand-200" aria-label="إنقاص"><Minus size={16} /></button>
            </div>
            <button
              onClick={handleAdd}
              className={cn(
                "flex flex-1 items-center justify-center gap-2 rounded-2xl py-4 text-[15px] font-bold shadow-xl transition-all hover:scale-[1.01]",
                added ? "bg-emerald-700 text-white" : "bg-ink-950 text-sand-100",
              )}
            >
              {added ? <><Check size={18} /> تمت الإضافة للسلة ✓</> : <><ShoppingBag size={18} /> أضف للسلة — {formatPrice(product.price * qty)}</>}
            </button>
          </div>

          {/* perks */}
          <div className="mt-5 grid grid-cols-3 gap-2.5">
            {[
              { icon: Truck, t: "شحن 2-4 أيام" },
              { icon: RotateCcw, t: "إرجاع 14 يوم" },
              { icon: ShieldCheck, t: "دفع آمن 100%" },
            ].map((f) => (
              <div key={f.t} className="flex flex-col items-center gap-1.5 rounded-2xl bg-white px-2 py-3.5 text-center ring-1 ring-ink-950/8">
                <f.icon size={18} className="text-gold-600" />
                <span className="text-[11.5px] font-bold">{f.t}</span>
              </div>
            ))}
          </div>

          {/* tabs */}
          <div className="mt-7 overflow-hidden rounded-[22px] bg-white ring-1 ring-ink-950/8">
            <div className="flex border-b border-ink-950/8">
              {[
                { id: "desc", l: "الوصف" },
                { id: "details", l: "التفاصيل والعناية" },
                { id: "ship", l: "الشحن والإرجاع" },
              ].map((t) => (
                <button
                  key={t.id}
                  onClick={() => setTab(t.id as typeof tab)}
                  className={cn("flex-1 py-4 text-[13px] font-bold transition-colors", tab === t.id ? "bg-ink-950 text-sand-100" : "text-ink-500 hover:text-ink-950")}
                >
                  {t.l}
                </button>
              ))}
            </div>
            <div className="p-6 text-[13.5px] leading-8 text-ink-700">
              {tab === "desc" && <p>{product.description}</p>}
              {tab === "details" && (
                <div>
                  <p className="font-bold text-ink-950">الخامة: {product.fabric}</p>
                  <p className="mt-2 whitespace-pre-line">{product.details}</p>
                </div>
              )}
              {tab === "ship" && (
                <ul className="list-disc space-y-1 pr-5">
                  <li>شحن لجميع ولايات الجزائر، والدفع عند الاستلام متاح.</li>
                  <li>إرجاع واستبدال خلال 14 يوم حسب سياسة المتجر.</li>
                  <li>الدفع عند الاستلام متاح حاليًا. الدفع الإلكتروني سيُفعّل بعد ربط بوابة دفع جزائرية.</li>
                </ul>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* related */}
      {related.length > 0 && (
        <div className="mt-20">
          <div className="flex items-end justify-between">
            <h2 className="font-display text-3xl font-bold md:text-4xl">قد يعجبك أيضاً</h2>
            <Link href="/shop" className="text-[13px] font-bold text-gold-700 hover:text-ink-950">عرض الكل ←</Link>
          </div>
          <div className="mt-6 grid grid-cols-2 gap-4 md:gap-6 lg:grid-cols-4">
            {related.map((p, i) => (
              <ProductCard key={p.slug} index={i} p={p} />
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
