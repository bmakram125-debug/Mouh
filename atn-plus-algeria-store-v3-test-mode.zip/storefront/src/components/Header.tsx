"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useState } from "react";
import { Menu, Search, ShoppingBag, X, Truck, Sparkles } from "lucide-react";
import { useCart } from "./cart-context";
import { cn } from "@/lib/format";

const links = [
  { href: "/", label: "الرئيسية" },
  { href: "/shop", label: "تسوّق" },
  { href: "/shop?collection=modest", label: "عبايات" },
  { href: "/shop?collection=street", label: "ستريت" },
  { href: "/shop?collection=winter", label: "الشتاء" },
];

export default function Header() {
  const { count, openCart } = useCart();
  const [scrolled, setScrolled] = useState(false);
  const [mobile, setMobile] = useState(false);
  const pathname = usePathname();

  useEffect(() => {
    const fn = () => setScrolled(window.scrollY > 24);
    fn();
    window.addEventListener("scroll", fn, { passive: true });
    return () => window.removeEventListener("scroll", fn);
  }, []);

  useEffect(() => setMobile(false), [pathname]);

  return (
    <>
      {/* top bar */}
      <div className="bg-ink-950 text-sand-100">
        <div className="mx-auto flex max-w-7xl items-center justify-center gap-2 px-4 py-2 text-[12px]">
          <Truck size={14} className="text-gold-400" />
          <p>
            شحن مجاني للطلبات فوق <b className="text-gold-300">10000 دج</b>
            <span className="mx-2 text-white/20">|</span>
            <span className="hidden sm:inline">إرجاع خلال 14 يوم</span>
            <span className="sm:hidden">إرجاع مجاني 14 يوم</span>
          </p>
        </div>
      </div>

      <header
        className={cn(
          "sticky top-0 z-40 transition-all duration-500",
          scrolled ? "bg-sand-100/85 shadow-[0_8px_30px_rgba(20,16,12,0.08)] backdrop-blur-xl" : "bg-sand-100",
        )}
      >
        <div className="mx-auto flex max-w-7xl items-center justify-between gap-4 px-4 py-3 md:px-8 md:py-4">
          {/* mobile menu btn */}
          <button onClick={() => setMobile(true)} className="grid h-11 w-11 place-items-center rounded-full ring-1 ring-ink-950/10 md:hidden" aria-label="القائمة">
            <Menu size={20} />
          </button>

          {/* nav desktop */}
          <nav className="hidden items-center gap-7 md:flex">
            {links.map((l) => (
              <Link
                key={l.href + l.label}
                href={l.href}
                className={cn(
                  "link-line text-[14px] font-semibold transition-colors",
                  pathname === l.href ? "text-ink-950" : "text-ink-500 hover:text-ink-950",
                )}
              >
                {l.label}
              </Link>
            ))}
          </nav>

          {/* logo */}
          <Link href="/" className="group flex items-center gap-3">
            <span className="grid h-11 w-11 place-items-center rounded-2xl bg-ink-950 text-sand-100 shadow-lg transition-transform duration-500 group-hover:rotate-[-8deg]">
              <span className="font-latin text-[15px] font-bold tracking-tight">
                atn<span className="text-gold-400">+</span>
              </span>
            </span>
            <span className="leading-tight">
              <span className="font-latin block text-[17px] font-bold tracking-tight text-ink-950">ATN+</span>
              <span className="block text-[11px] font-medium text-ink-400">أزياء عربية بروح عالمية</span>
            </span>
          </Link>

          {/* actions */}
          <div className="flex items-center gap-2">
            <Link href="/shop" aria-label="بحث" className="hidden h-11 w-11 place-items-center rounded-full ring-1 ring-ink-950/10 transition-colors hover:bg-white sm:grid">
              <Search size={18} />
            </Link>
            <Link
              href="/shop"
              className="hidden items-center gap-1.5 rounded-full bg-gold-500/15 px-4 py-2.5 text-[13px] font-bold text-gold-700 ring-1 ring-gold-500/30 transition-colors hover:bg-gold-500 hover:text-ink-950 lg:flex"
            >
              <Sparkles size={15} /> تشكيلة الشتاء
            </Link>
            <button
              onClick={openCart}
              className="relative flex items-center gap-2 rounded-full bg-ink-950 px-5 py-3 text-[13px] font-bold text-sand-100 shadow-[0_10px_25px_rgba(20,16,12,0.25)] transition-transform hover:scale-[1.03] active:scale-[0.98]"
            >
              <ShoppingBag size={17} />
              <span className="hidden sm:inline">السلة</span>
              {count > 0 && (
                <span className="absolute -top-1.5 -left-1.5 grid h-6 min-w-6 place-items-center rounded-full bg-clay-500 px-1 text-[11px] font-bold text-white ring-2 ring-sand-100">
                  {count > 99 ? "99+" : count}
                </span>
              )}
            </button>
          </div>
        </div>
      </header>

      {/* mobile drawer */}
      {mobile && (
        <div className="fixed inset-0 z-[60] md:hidden">
          <div className="drawer-overlay absolute inset-0 bg-ink-950/50 backdrop-blur-sm" onClick={() => setMobile(false)} />
          <div className="drawer-panel absolute top-0 right-0 flex h-full w-[82%] max-w-sm flex-col bg-sand-100 p-6 shadow-2xl">
            <div className="flex items-center justify-between">
              <span className="font-latin text-xl font-bold">
                atn<span className="text-gold-600">+</span>
              </span>
              <button onClick={() => setMobile(false)} className="grid h-10 w-10 place-items-center rounded-full bg-white ring-1 ring-ink-950/10" aria-label="إغلاق">
                <X size={18} />
              </button>
            </div>
            <nav className="mt-8 flex flex-col gap-1">
              {links.map((l, i) => (
                <Link
                  key={l.label + i}
                  href={l.href}
                  className="rounded-2xl px-4 py-4 text-lg font-bold text-ink-900 transition-colors hover:bg-white"
                >
                  {l.label}
                </Link>
              ))}
              <Link href="/checkout" className="mt-4 rounded-2xl bg-ink-950 px-4 py-4 text-center text-[15px] font-bold text-sand-100">
                إتمام الطلب
              </Link>
            </nav>
            <p className="mt-auto text-center text-[12px] text-ink-400">شحن سريع لجميع ولايات الجزائر 🚚</p>
          </div>
        </div>
      )}
    </>
  );
}
