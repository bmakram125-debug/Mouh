"use client";

import Link from "next/link";
import Image from "next/image";
import { X, Minus, Plus, Trash2, ShoppingBag, Truck, Lock } from "lucide-react";
import { useCart } from "./cart-context";
import { formatPrice } from "@/lib/format";

const FREE_SHIP = 300;

export default function CartDrawer() {
  const { items, subtotal, isOpen, closeCart, updateQty, removeItem } = useCart();
  const progress = Math.min(100, (subtotal / FREE_SHIP) * 100);
  const remaining = Math.max(0, FREE_SHIP - subtotal);

  return (
    <div className={`fixed inset-0 z-[70] ${isOpen ? "" : "pointer-events-none"}`} aria-hidden={!isOpen}>
      <div
        className={`drawer-overlay absolute inset-0 bg-ink-950/55 backdrop-blur-sm ${isOpen ? "opacity-100" : "opacity-0"}`}
        onClick={closeCart}
      />
      <aside
        className={`drawer-panel absolute top-0 left-0 flex h-full w-full max-w-md flex-col bg-sand-100 shadow-2xl ${
          isOpen ? "translate-x-0" : "-translate-x-full"
        }`}
      >
        {/* head */}
        <div className="flex items-center justify-between border-b border-ink-950/10 px-6 py-5">
          <h3 className="flex items-center gap-2 text-lg font-bold">
            <ShoppingBag size={19} /> سلة التسوق
            <span className="rounded-full bg-ink-950 px-2.5 py-0.5 text-[12px] font-bold text-sand-100">{items.length}</span>
          </h3>
          <button onClick={closeCart} className="grid h-10 w-10 place-items-center rounded-full bg-white ring-1 ring-ink-950/10 hover:bg-ink-950 hover:text-white" aria-label="إغلاق السلة">
            <X size={18} />
          </button>
        </div>

        {/* free shipping bar */}
        <div className="border-b border-ink-950/10 bg-white/60 px-6 py-4">
          <p className="flex items-center gap-2 text-[12.5px] font-semibold">
            <Truck size={15} className="text-gold-600" />
            {remaining > 0 ? (
              <>أضف بقيمة <b>{formatPrice(remaining)}</b> واحصل على شحن مجاني</>
            ) : (
              <span className="text-emerald-700">🎉 مبروك! شحنك مجاني الآن</span>
            )}
          </p>
          <div className="mt-2.5 h-2 overflow-hidden rounded-full bg-ink-950/10">
            <div className="h-full rounded-full bg-gradient-to-l from-gold-600 to-gold-400 transition-all duration-700" style={{ width: `${progress}%` }} />
          </div>
        </div>

        {/* items */}
        <div className="flex-1 overflow-y-auto px-6 py-4">
          {items.length === 0 ? (
            <div className="flex h-full flex-col items-center justify-center gap-4 text-center">
              <span className="grid h-20 w-20 place-items-center rounded-full bg-white text-ink-400 ring-1 ring-ink-950/10">
                <ShoppingBag size={30} />
              </span>
              <p className="text-[15px] font-bold">سلتك فارغة</p>
              <p className="max-w-[240px] text-[13px] leading-6 text-ink-500">اكتشف تشكيلاتنا الجديدة واختر قطعاً تليق بك</p>
              <button onClick={closeCart} className="mt-2 rounded-full bg-ink-950 px-7 py-3 text-[13px] font-bold text-sand-100">
                <Link href="/shop">ابدأ التسوق</Link>
              </button>
            </div>
          ) : (
            <ul className="space-y-4">
              {items.map((it) => (
                <li key={it.key} className="flex gap-3 rounded-3xl bg-white p-3 ring-1 ring-ink-950/5">
                  <div className="relative h-24 w-20 shrink-0 overflow-hidden rounded-2xl bg-sand-200">
                    <Image src={it.image} alt={it.name} fill className="object-cover" sizes="80px" />
                  </div>
                  <div className="flex min-w-0 flex-1 flex-col">
                    <div className="flex items-start justify-between gap-2">
                      <p className="truncate text-[13.5px] font-bold">{it.name}</p>
                      <button onClick={() => removeItem(it.key)} className="text-ink-400 transition-colors hover:text-red-600" aria-label="حذف">
                        <Trash2 size={15} />
                      </button>
                    </div>
                    <p className="mt-0.5 text-[11.5px] text-ink-400">
                      {it.color} • مقاس {it.size}
                    </p>
                    <div className="mt-auto flex items-center justify-between pt-2">
                      <div className="flex items-center gap-1 rounded-full bg-sand-100 p-1 ring-1 ring-ink-950/10">
                        <button onClick={() => updateQty(it.key, it.qty + 1)} className="grid h-7 w-7 place-items-center rounded-full bg-white shadow-sm" aria-label="زيادة">
                          <Plus size={13} />
                        </button>
                        <span className="w-7 text-center text-[13px] font-bold">{it.qty}</span>
                        <button onClick={() => updateQty(it.key, it.qty - 1)} className="grid h-7 w-7 place-items-center rounded-full bg-white shadow-sm" aria-label="إنقاص">
                          <Minus size={13} />
                        </button>
                      </div>
                      <p className="text-[14px] font-bold">{formatPrice(it.price * it.qty)}</p>
                    </div>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </div>

        {/* foot */}
        {items.length > 0 && (
          <div className="border-t border-ink-950/10 bg-white px-6 py-5">
            <div className="flex justify-between text-[13px] text-ink-500">
              <span>المجموع الفرعي</span>
              <span className="font-bold text-ink-950">{formatPrice(subtotal)}</span>
            </div>
            <div className="mt-1 flex justify-between text-[13px] text-ink-500">
              <span>الشحن</span>
              <span>{subtotal >= FREE_SHIP ? "مجاني" : "يُحسب عند الدفع"}</span>
            </div>
            <Link
              href="/checkout"
              onClick={closeCart}
              className="mt-4 flex w-full items-center justify-center gap-2 rounded-2xl bg-ink-950 py-4 text-[14px] font-bold text-sand-100 shadow-xl transition-transform hover:scale-[1.01]"
            >
              <Lock size={15} /> إتمام الطلب بأمان
            </Link>
            <button onClick={closeCart} className="mt-2 w-full py-2 text-center text-[13px] font-semibold text-ink-500 hover:text-ink-950">
              مواصلة التسوق
            </button>
          </div>
        )}
      </aside>
    </div>
  );
}
