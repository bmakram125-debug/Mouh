"use client";

import { useMemo, useState } from "react";
import { useSearchParams } from "next/navigation";
import { SlidersHorizontal, X, Search, BadgePercent } from "lucide-react";
import ProductCard, { type CardProduct } from "./ProductCard";
import { cn } from "@/lib/format";

type Props = {
  products: CardProduct[];
  collections: { slug: string; name: string }[];
  categories: string[];
};

const sorts = [
  { id: "featured", label: "المميز أولاً" },
  { id: "best", label: "الأكثر مبيعاً" },
  { id: "rating", label: "الأعلى تقييماً" },
  { id: "new", label: "الأحدث" },
  { id: "low", label: "السعر: من الأقل" },
  { id: "high", label: "السعر: من الأعلى" },
] as const;

export default function ShopClient({ products, collections, categories }: Props) {
  const params = useSearchParams();
  const initialCol = params.get("collection") ?? "all";

  const [query, setQuery] = useState("");
  const [collection, setCollection] = useState(initialCol);
  const [category, setCategory] = useState("all");
  const [maxPrice, setMaxPrice] = useState(800);
  const [minRating, setMinRating] = useState(0);
  const [saleOnly, setSaleOnly] = useState(false);
  const [sort, setSort] = useState<string>((params.get("sort") === "best" ? "best" : "featured") as string);
  const [filtersOpen, setFiltersOpen] = useState(false);

  // need collection slug lookup: products carry no slug here — we passed CardProduct without collection.
  // We'll rely on data-col attribute via extended products prop instead.
  const extended = products as (CardProduct & { _col?: string; _sold?: number; _new?: boolean })[];

  const filtered = useMemo(() => {
    let list = [...extended];
    if (collection !== "all") list = list.filter((p) => p._col === collection);
    if (category !== "all") list = list.filter((p) => p.category === category);
    if (query.trim()) {
      const q = query.trim();
      list = list.filter((p) => p.name.includes(q) || p.nameEn.toLowerCase().includes(q.toLowerCase()) || p.category.includes(q));
    }
    list = list.filter((p) => p.price <= maxPrice);
    if (minRating > 0) list = list.filter((p) => p.rating >= minRating);
    if (saleOnly) list = list.filter((p) => p.compareAtPrice && p.compareAtPrice > p.price);
    switch (sort) {
      case "best": list.sort((a, b) => (b._sold ?? 0) - (a._sold ?? 0)); break;
      case "rating": list.sort((a, b) => b.rating - a.rating); break;
      case "new": list.sort((a, b) => Number(b.isNew) - Number(a.isNew)); break;
      case "low": list.sort((a, b) => a.price - b.price); break;
      case "high": list.sort((a, b) => b.price - a.price); break;
      default: break;
    }
    return list;
  }, [extended, collection, category, query, maxPrice, minRating, saleOnly, sort]);

  const hasActive = collection !== "all" || category !== "all" || query !== "" || maxPrice < 800 || minRating > 0 || saleOnly;
  const clear = () => {
    setCollection("all"); setCategory("all"); setQuery(""); setMaxPrice(800); setMinRating(0); setSaleOnly(false);
  };

  const Filters = (
    <div className="space-y-7">
      {/* collections */}
      <div>
        <h4 className="text-[13px] font-bold text-ink-950">التشكيلة</h4>
        <div className="mt-3 space-y-1.5">
          {[{ slug: "all", name: "الكل" }, ...collections].map((c) => (
            <button
              key={c.slug}
              onClick={() => setCollection(c.slug)}
              className={cn(
                "flex w-full items-center justify-between rounded-2xl px-4 py-2.5 text-[13.5px] font-semibold transition-all",
                collection === c.slug ? "bg-ink-950 text-sand-100 shadow-lg" : "text-ink-500 hover:bg-white",
              )}
            >
              {c.name}
              {collection === c.slug && <span className="h-2 w-2 rounded-full bg-gold-400" />}
            </button>
          ))}
        </div>
      </div>
      {/* categories */}
      <div>
        <h4 className="text-[13px] font-bold text-ink-950">الفئة</h4>
        <div className="mt-3 flex flex-wrap gap-2">
          {["all", ...categories].map((c) => (
            <button
              key={c}
              onClick={() => setCategory(c)}
              className={cn(
                "rounded-full px-4 py-2 text-[12.5px] font-bold ring-1 transition-all",
                category === c ? "bg-gold-500 text-ink-950 ring-gold-500" : "bg-white text-ink-500 ring-ink-950/10 hover:ring-ink-950/30",
              )}
            >
              {c === "all" ? "الكل" : c}
            </button>
          ))}
        </div>
      </div>
      {/* price */}
      <div>
        <div className="flex items-center justify-between">
          <h4 className="text-[13px] font-bold text-ink-950">السعر الأقصى</h4>
          <span className="rounded-full bg-white px-3 py-1 text-[12px] font-bold ring-1 ring-ink-950/10">{maxPrice} دج</span>
        </div>
        <input
          type="range" min={80} max={800} step={10} value={maxPrice}
          onChange={(e) => setMaxPrice(Number(e.target.value))}
          className="mt-4 w-full accent-[#1D1813]"
          dir="ltr"
        />
        <div className="flex justify-between text-[11px] text-ink-400"><span>800</span><span>80</span></div>
      </div>
      {/* rating */}
      <div>
        <h4 className="text-[13px] font-bold text-ink-950">التقييم</h4>
        <div className="mt-3 flex gap-2">
          {[0, 4, 4.5, 4.8].map((r) => (
            <button
              key={r}
              onClick={() => setMinRating(r)}
              className={cn(
                "rounded-full px-3.5 py-2 text-[12px] font-bold ring-1 transition-all",
                minRating === r ? "bg-ink-950 text-sand-100 ring-ink-950" : "bg-white text-ink-500 ring-ink-950/10",
              )}
            >
              {r === 0 ? "الكل" : `${r}+ ★`}
            </button>
          ))}
        </div>
      </div>
      {/* sale */}
      <button
        onClick={() => setSaleOnly((v) => !v)}
        className={cn(
          "flex w-full items-center justify-between rounded-2xl px-4 py-3.5 text-[13px] font-bold ring-1 transition-all",
          saleOnly ? "bg-clay-500 text-white ring-clay-500" : "bg-white text-ink-700 ring-ink-950/10",
        )}
      >
        <span className="flex items-center gap-2"><BadgePercent size={16} /> العروض والتخفيضات فقط</span>
        <span className={cn("grid h-6 w-11 place-items-center rounded-full transition-colors", saleOnly ? "bg-white/25" : "bg-ink-950/10")}>
          <span className={cn("h-4 w-4 rounded-full bg-white shadow transition-transform", saleOnly ? "-translate-x-2.5" : "translate-x-2.5")} />
        </span>
      </button>
      {hasActive && (
        <button onClick={clear} className="w-full rounded-2xl border border-dashed border-ink-950/25 py-3 text-[13px] font-bold text-ink-500 hover:text-ink-950">
          مسح جميع الفلاتر ✕
        </button>
      )}
    </div>
  );

  return (
    <div className="grid gap-8 lg:grid-cols-[260px_1fr]">
      {/* sidebar desktop */}
      <aside className="hidden lg:block">
        <div className="sticky top-28 rounded-[24px] bg-sand-200/50 p-6 ring-1 ring-ink-950/8">{Filters}</div>
      </aside>

      <div>
        {/* toolbar */}
        <div className="flex flex-col gap-3 rounded-[24px] bg-white p-4 ring-1 ring-ink-950/8 md:flex-row md:items-center">
          <div className="flex flex-1 items-center gap-2 rounded-2xl bg-sand-100 px-4 py-3 ring-1 ring-ink-950/8 focus-within:ring-ink-950">
            <Search size={17} className="shrink-0 text-ink-400" />
            <input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="ابحث عن عباية، هودي، ثوب..." className="w-full bg-transparent text-[13.5px] outline-none placeholder:text-ink-400" />
            {query && <button onClick={() => setQuery("")} aria-label="مسح"><X size={15} className="text-ink-400" /></button>}
          </div>
          <div className="flex items-center gap-2">
            <button onClick={() => setFiltersOpen(true)} className="flex items-center gap-2 rounded-2xl bg-sand-100 px-5 py-3 text-[13px] font-bold ring-1 ring-ink-950/8 lg:hidden">
              <SlidersHorizontal size={15} /> الفلاتر
            </button>
            <select value={sort} onChange={(e) => setSort(e.target.value)} className="flex-1 cursor-pointer rounded-2xl bg-ink-950 px-4 py-3 text-[13px] font-bold text-sand-100 outline-none md:flex-none">
              {sorts.map((s) => <option key={s.id} value={s.id}>{s.label}</option>)}
            </select>
          </div>
        </div>

        <p className="mt-5 text-[13px] text-ink-500">
          عرض <b className="text-ink-950">{filtered.length}</b> من <b className="text-ink-950">{products.length}</b> منتجاً
          {collection !== "all" && <> في تشكيلة <b className="text-gold-700">{collections.find((c) => c.slug === collection)?.name}</b></>}
        </p>

        {filtered.length === 0 ? (
          <div className="mt-6 flex flex-col items-center gap-3 rounded-[24px] bg-white px-6 py-20 text-center ring-1 ring-ink-950/8">
            <span className="text-5xl">🛍️</span>
            <p className="text-lg font-bold">لا توجد نتائج مطابقة</p>
            <p className="max-w-sm text-[13.5px] leading-7 text-ink-500">جرّب كلمة بحث مختلفة أو وسّع نطاق السعر والفلاتر.</p>
            <button onClick={clear} className="mt-2 rounded-full bg-ink-950 px-7 py-3 text-[13px] font-bold text-sand-100">مسح الفلاتر</button>
          </div>
        ) : (
          <div className="mt-5 grid grid-cols-2 gap-4 md:gap-6 xl:grid-cols-3">
            {filtered.map((p, i) => (
              <ProductCard key={p.slug} index={i} p={p} />
            ))}
          </div>
        )}
      </div>

      {/* mobile filters drawer */}
      {filtersOpen && (
        <div className="fixed inset-0 z-[70] lg:hidden">
          <div className="drawer-overlay absolute inset-0 bg-ink-950/55" onClick={() => setFiltersOpen(false)} />
          <div className="drawer-panel absolute top-0 right-0 flex h-full w-[86%] max-w-sm flex-col bg-sand-100 shadow-2xl">
            <div className="flex items-center justify-between border-b border-ink-950/10 px-6 py-5">
              <h3 className="flex items-center gap-2 font-bold"><SlidersHorizontal size={17} /> الفلاتر والترتيب</h3>
              <button onClick={() => setFiltersOpen(false)} className="grid h-10 w-10 place-items-center rounded-full bg-white ring-1 ring-ink-950/10" aria-label="إغلاق"><X size={17} /></button>
            </div>
            <div className="flex-1 overflow-y-auto px-6 py-6">{Filters}</div>
            <div className="border-t border-ink-950/10 bg-white p-4">
              <button onClick={() => setFiltersOpen(false)} className="w-full rounded-2xl bg-ink-950 py-4 text-[14px] font-bold text-sand-100">
                عرض {filtered.length} منتجاً
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
