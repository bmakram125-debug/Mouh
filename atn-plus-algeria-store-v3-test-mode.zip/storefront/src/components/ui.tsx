"use client";

import { useEffect, useRef } from "react";
import { Star, StarHalf } from "lucide-react";
import { cn } from "@/lib/format";

export function Stars({ value, className }: { value: number; className?: string }) {
  const full = Math.floor(value);
  const half = value - full >= 0.4;
  return (
    <span className={cn("inline-flex items-center gap-0.5 text-gold-600", className)} dir="ltr">
      {Array.from({ length: 5 }).map((_, i) => {
        if (i < full) return <Star key={i} size={14} fill="currentColor" strokeWidth={0} />;
        if (i === full && half)
          return (
            <span key={i} className="relative inline-flex">
              <Star size={14} className="text-ink-900/15" fill="currentColor" strokeWidth={0} />
              <span className="absolute inset-0 overflow-hidden" style={{ width: "50%" }}>
                <Star size={14} fill="currentColor" strokeWidth={0} />
              </span>
            </span>
          );
        return <Star key={i} size={14} className="text-ink-900/15" fill="currentColor" strokeWidth={0} />;
      })}
    </span>
  );
}

export function Reveal({
  children,
  className,
  delay,
}: {
  children: React.ReactNode;
  className?: string;
  delay?: 1 | 2 | 3;
}) {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const obs = new IntersectionObserver(
      (entries) => {
        entries.forEach((e) => {
          if (e.isIntersecting) {
            e.target.classList.add("is-visible");
            obs.unobserve(e.target);
          }
        });
      },
      { threshold: 0.12 },
    );
    obs.observe(el);
    return () => obs.disconnect();
  }, []);
  return (
    <div ref={ref} className={cn("reveal", delay === 1 && "reveal-delay-1", delay === 2 && "reveal-delay-2", delay === 3 && "reveal-delay-3", className)}>
      {children}
    </div>
  );
}

export function Marquee({ items }: { items: string[] }) {
  const doubled = [...items, ...items];
  return (
    <div className="overflow-hidden border-y border-ink-900/10 bg-ink-950 py-3 text-sand-100" dir="ltr">
      <div className="marquee-track gap-0">
        {doubled.map((t, i) => (
          <span key={i} className="mx-6 flex shrink-0 items-center gap-6 text-[13px] tracking-wide whitespace-nowrap">
            <span className="font-latin text-[11px] tracking-[0.3em] text-gold-400">ATN+</span>
            <span>{t}</span>
            <span className="text-gold-500">✦</span>
          </span>
        ))}
      </div>
    </div>
  );
}

export function SectionHeading({
  kicker,
  title,
  sub,
  align = "center",
}: {
  kicker: string;
  title: string;
  sub?: string;
  align?: "center" | "start";
}) {
  return (
    <Reveal className={align === "center" ? "mx-auto max-w-2xl text-center" : "max-w-2xl"}>
      <p className="font-latin text-[11px] font-semibold tracking-[0.35em] text-gold-600 uppercase">{kicker}</p>
      <h2 className="font-display mt-3 text-4xl leading-[1.15] font-bold text-ink-950 md:text-5xl">{title}</h2>
      {sub && <p className="mt-4 text-[15px] leading-8 text-ink-500">{sub}</p>}
      <div className={`mt-5 flex items-center gap-2 ${align === "center" ? "justify-center" : ""}`}>
        <span className="h-px w-10 bg-gold-500" />
        <span className="h-1.5 w-1.5 rotate-45 bg-gold-500" />
        <span className="h-px w-10 bg-gold-500" />
      </div>
    </Reveal>
  );
}
