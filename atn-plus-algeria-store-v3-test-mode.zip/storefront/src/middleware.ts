import { NextRequest, NextResponse } from "next/server";
import { ADMIN_COOKIE, isValidAdminToken } from "@/lib/admin-auth";
export function middleware(req:NextRequest){const p=req.nextUrl.pathname;if(p==="/admin/login"||p==="/api/admin/login")return NextResponse.next();if(p.startsWith("/admin")||p.startsWith("/api/admin")){if(!isValidAdminToken(req.cookies.get(ADMIN_COOKIE)?.value)){if(p.startsWith("/api/"))return NextResponse.json({error:"غير مصرح"},{status:401});return NextResponse.redirect(new URL("/admin/login",req.url));}}return NextResponse.next()}
export const config={matcher:["/admin/:path*","/api/admin/:path*"]};
