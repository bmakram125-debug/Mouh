export function formatPrice(n: number): string {
  return `${n.toLocaleString("ar-DZ")} دج`;
}

export function formatPriceLatin(n: number): string {
  return `${n.toLocaleString("fr-DZ")} DZD`;
}

export function discountPct(price: number, compare?: number | null): number | null {
  if (!compare || compare <= price) return null;
  return Math.round(((compare - price) / compare) * 100);
}

export function cn(...parts: Array<string | false | null | undefined>): string {
  return parts.filter(Boolean).join(" ");
}
