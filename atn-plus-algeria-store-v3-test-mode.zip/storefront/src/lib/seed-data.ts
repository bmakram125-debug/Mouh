export type SeedColor = { name: string; hex: string };

export type SeedProduct = {
  slug: string;
  name: string;
  nameEn: string;
  description: string;
  details: string;
  price: number;
  compareAtPrice?: number;
  category: string;
  categoryEn: string;
  collectionSlug: string;
  images: string[];
  colors: SeedColor[];
  sizes: string[];
  fabric: string;
  stock: number;
  rating: number;
  reviewCount: number;
  soldCount: number;
  isFeatured: boolean;
  isNew: boolean;
  badge?: string;
  tags: string[];
};

export type SeedCollection = {
  slug: string;
  name: string;
  nameEn: string;
  tagline: string;
  description: string;
  image: string;
  accent: string;
  sort: number;
};

export type SeedReview = {
  productSlug: string;
  author: string;
  city: string;
  rating: number;
  title: string;
  body: string;
  helpful: number;
};

const px = (id: number, ext = "jpeg") =>
  `https://images.pexels.com/photos/${id}/pexels-photo-${id}.${ext}?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800`;

export const seedCollections: SeedCollection[] = [
  {
    slug: "essentials",
    name: "أساسيات ATN+",
    nameEn: "Essentials",
    tagline: "قطع يومية بجودة تدوم",
    description:
      "تشكيلة الأساسيات التي لا غنى عنها: تيشيرتات قطنية، قمصان كتان، وأثواب بقصّات مدروسة وأقمشة مختارة بعناية لتدوم معك كل يوم.",
    image: px(8217291),
    accent: "#C9A86A",
    sort: 1,
  },
  {
    slug: "street",
    name: "ستريت إيدج",
    nameEn: "Street Edge",
    tagline: "روح الشارع بلمسة راقية",
    description:
      "هوديات أوفرسايز، دينم، وقطع ستريت وير بروح عربية جريئة. صُممت للحركة، للمدينة، وللحضور الذي لا يُنسى.",
    image: px(30410057),
    accent: "#1D1813",
    sort: 2,
  },
  {
    slug: "modest",
    name: "أناقة محتشمة",
    nameEn: "Modest Elegance",
    tagline: "عبايات وفساتين بتصميم عصري",
    description:
      "عبايات انسيابية، فساتين سهرة مطرزة، وحجابات مختارة بعناية. احتشام راقٍ بتفاصيل كوتور وأقمشة تليق بمناسباتك.",
    image: px(37558001),
    accent: "#7E6132",
    sort: 3,
  },
  {
    slug: "winter",
    name: "دفء الشتاء",
    nameEn: "Winter Warmth",
    tagline: "معاطف وصوف لشتاء لا يُنسى",
    description:
      "معاطف الجمل الفاخرة، كنزات الصوف الناعمة، وقطع الشتاء الثقيلة بخامات دافئة وقصّات تحتضنك بأناقة.",
    image: px(36180266),
    accent: "#5F6650",
    sort: 4,
  },
];

export const seedProducts: SeedProduct[] = [
  {
    slug: "premium-tee-white",
    name: "تيشيرت بريميوم قطن 100%",
    nameEn: "Premium Cotton Tee",
    description:
      "تيشيرتنا الأيقوني بقصّة مريحة قليلاً وقطن مصري 220غ. ملمس ناعم، ثبات في اللون بعد الغسيل، وياقة مضلعة لا تترهل. القطعة التي ستشتري منها ثلاثة ألوان.",
    details:
      "• قطن مصري 100% بوزن 220غ\n• قصّة عادية مريحة (Regular Fit)\n• ياقة مضلعة مزدوجة\n• خياطة كتف مسطحة لمنع الاحتكاك\n• يُغسل بماء بارد ويُكوى على الوجه الداخلي",
    price: 8900,
    compareAtPrice: 12900,
    category: "تيشيرتات",
    categoryEn: "T-Shirts",
    collectionSlug: "essentials",
    images: [px(8217291), px(8058966), px(7705920)],
    colors: [
      { name: "أبيض", hex: "#FFFFFF" },
      { name: "بيج", hex: "#E9DDC8" },
      { name: "أسود", hex: "#1D1813" },
    ],
    sizes: ["S", "M", "L", "XL", "XXL"],
    fabric: "قطن مصري 100%",
    stock: 240,
    rating: 4.8,
    reviewCount: 214,
    soldCount: 1830,
    isFeatured: true,
    isNew: false,
    badge: "الأكثر مبيعاً",
    tags: ["قطن", "يومي", "أساسي"],
  },
  {
    slug: "linen-shirt-beige",
    name: "قميص كتان بيج بأزرار خشبية",
    nameEn: "Beige Linen Shirt",
    description:
      "قميص كتان أوروبي بلمسة ATN+ : خفيف، يتنفس، ويزداد جمالاً مع كل لبسة. أزرار خشبية طبيعية وجيب صدر واحد. مثالي للدوام والطلعات الصيفية.",
    details:
      "• كتان أوروبي 100% مغسول مسبقاً\n• قصّة مريحة بأكمام قابلة للطي\n• أزرار خشب زيتون طبيعي\n• خياطة فرنسية داخلية فاخرة",
    price: 18900,
    category: "قمصان",
    categoryEn: "Shirts",
    collectionSlug: "essentials",
    images: [px(7705920), px(8532623), px(8058966)],
    colors: [
      { name: "بيج", hex: "#D9C6A5" },
      { name: "أبيض", hex: "#FFFFFF" },
      { name: "زيتي", hex: "#5F6650" },
    ],
    sizes: ["S", "M", "L", "XL"],
    fabric: "كتان أوروبي 100%",
    stock: 120,
    rating: 4.7,
    reviewCount: 96,
    soldCount: 640,
    isFeatured: true,
    isNew: true,
    badge: "جديد",
    tags: ["كتان", "صيف", "دوام"],
  },
  {
    slug: "iconic-black-hoodie",
    name: "هودي ATN+ الأسود الأيقوني",
    nameEn: "Iconic Black Hoodie",
    description:
      "الهودي الذي بدأت منه الحكاية. قطن مبطّن بوزن 400غ، قصّة أوفرسايز مدروسة، وجيب كنغر مخفي بسحاب. شعار + مطرز بدقة على الصدر. ثقيل، دافئ، ولا يتوبّر.",
    details:
      "• قطن 80% + بوليستر 20% بوزن 400غ\n• بطانة فرنش تيري ناعمة\n• قبعة مزدوجة الطبقات بأربطة مسطحة\n• طبعة وتطريز عالي الثبات",
    price: 24900,
    compareAtPrice: 31900,
    category: "هوديات",
    categoryEn: "Hoodies",
    collectionSlug: "street",
    images: [px(28701960), px(15127546), px(16166526)],
    colors: [
      { name: "أسود", hex: "#1D1813" },
      { name: "رمادي", hex: "#8C7F74" },
      { name: "بيج", hex: "#E9DDC8" },
    ],
    sizes: ["S", "M", "L", "XL", "XXL"],
    fabric: "قطن مبطّن 400غ",
    stock: 180,
    rating: 4.9,
    reviewCount: 342,
    soldCount: 2610,
    isFeatured: true,
    isNew: false,
    badge: "خصم 22%",
    tags: ["هودي", "ستريت", "شتاء"],
  },
  {
    slug: "oversized-white-hoodie",
    name: "هودي أوفرسايز أبيض سكري",
    nameEn: "Oversized Cream Hoodie",
    description:
      "هودي أوفرسايز بلون سكري دافئ، بقصّة واسعة وأكتاف ساقطة على طريقة الستريت الكوري. خامة قطنية ناعمة من الداخل تصلح للطلعات الليلية والجامعة.",
    details: "• قصّة أوفرسايز بأكتاف ساقطة\n• قطن 100% بملمس خوخي\n• ياقة وأساور مضلعة سميكة\n• لون سكري لا يشف",
    price: 22900,
    category: "هوديات",
    categoryEn: "Hoodies",
    collectionSlug: "street",
    images: [px(30283474), px(29852348), px(30410057)],
    colors: [
      { name: "سكري", hex: "#F3EDE1" },
      { name: "أبيض", hex: "#FFFFFF" },
    ],
    sizes: ["M", "L", "XL"],
    fabric: "قطن 100%",
    stock: 95,
    rating: 4.6,
    reviewCount: 78,
    soldCount: 420,
    isFeatured: false,
    isNew: true,
    badge: "جديد",
    tags: ["هودي", "أوفرسايز", "جامعة"],
  },
  {
    slug: "burgundy-street-hoodie",
    name: "هودي ستريت عنابي",
    nameEn: "Burgundy Street Hoodie",
    description:
      "لون عنابي جريء بقصّة بوكسي وقماش سميك يوقف. صُمم للشتاء الحقيقي: يدفي، يثبت شكله، ويعطيك حضوراً في أي مكان.",
    details: "• قصّة بوكسي عريضة\n• بطانة دافئة 380غ\n• جيب كنغر + جيب داخلي للجوال\n• خياطة مسطحة مريحة",
    price: 25900,
    category: "هوديات",
    categoryEn: "Hoodies",
    collectionSlug: "street",
    images: [px(29652516), px(21356439), px(28701960)],
    colors: [
      { name: "عنابي", hex: "#6E1E2A" },
      { name: "أسود", hex: "#1D1813" },
    ],
    sizes: ["S", "M", "L", "XL"],
    fabric: "قطن مبطّن 380غ",
    stock: 70,
    rating: 4.7,
    reviewCount: 64,
    soldCount: 380,
    isFeatured: false,
    isNew: false,
    tags: ["هودي", "شتاء"],
  },
  {
    slug: "classic-black-abaya",
    name: "عباية سوداء كلاسيكية انسيابية",
    nameEn: "Classic Flowy Black Abaya",
    description:
      "عباية ATN+ الأكثر طلباً: قماش ندى كوري فاخر، قصّة انسيابية تخفي ولا تحجم، وأكمام واسعة مريحة. سواد فاحم لا يبهت، وخياطة نظيفة تدوم لسنوات.",
    details:
      "• قماش ندى كوري فاخر\n• قصّة كلوش انسيابية\n• طرحة مطابقة هدية\n• أزرار أمامية مخفية + سحاب\n• متوفرة بأطوال 52 / 54 / 56 / 58",
    price: 34900,
    compareAtPrice: 44900,
    category: "عبايات",
    categoryEn: "Abayas",
    collectionSlug: "modest",
    images: [px(37558001), px(32279499), px(13791329)],
    colors: [
      { name: "أسود", hex: "#0F0F0F" },
      { name: "كحلي", hex: "#1E2A44" },
    ],
    sizes: ["52", "54", "56", "58"],
    fabric: "ندى كوري فاخر",
    stock: 150,
    rating: 4.9,
    reviewCount: 428,
    soldCount: 3120,
    isFeatured: true,
    isNew: false,
    badge: "الأعلى تقييماً",
    tags: ["عباية", "يومي", "محتشم"],
  },
  {
    slug: "gold-embroidered-abaya",
    name: "عباية مطرزة بخيوط ذهبية",
    nameEn: "Gold Embroidered Abaya",
    description:
      "للمناسبات التي تستحق أن تتألقي فيها: عباية سوداء بتطريز ذهبي دقيق على الأكمام والأطراف، بقصّة أميرية تمنحك وقفة ملكية. قطعة كوتور بسعر عادل.",
    details:
      "• تطريز ذهبي يدوي دقيق\n• قصّة أميرية بقصّة خصر خفيفة\n• بطانة ساتان ناعمة\n• علبة هدايا فاخرة + طرحة شيفون",
    price: 54900,
    category: "عبايات",
    categoryEn: "Abayas",
    collectionSlug: "modest",
    images: [px(13838842), px(13776526), px(5973515)],
    colors: [
      { name: "أسود × ذهبي", hex: "#1D1813" },
      { name: "أسود × فضي", hex: "#3D342E" },
    ],
    sizes: ["52", "54", "56", "58", "60"],
    fabric: "ندى + تطريز حريري",
    stock: 60,
    rating: 4.8,
    reviewCount: 112,
    soldCount: 540,
    isFeatured: true,
    isNew: true,
    badge: "قطعة مميزة",
    tags: ["عباية", "مناسبات", "مطرز"],
  },
  {
    slug: "beige-evening-dress",
    name: "فستان سهرة بيج مطرز",
    nameEn: "Beige Embroidered Evening Dress",
    description:
      "فستان سهرة بلون الشمبين بتطريز ناعم يلمع تحت الإضاءة. قصّة محتشمة بأكمام طويلة وذيل انسيابي. خُيط ليكون فستان الذكريات الحلوة.",
    details: "• قماش تول مبطن بساتان\n• تطريز خرز وترتر ثابت\n• سحاب خلفي مخفي\n• يتضمن حزام خصر رفيع",
    price: 64900,
    compareAtPrice: 79900,
    category: "فساتين",
    categoryEn: "Dresses",
    collectionSlug: "modest",
    images: [px(15751106), px(15751104), px(7377534)],
    colors: [
      { name: "شمبين", hex: "#E9DDC8" },
      { name: "موف", hex: "#B9A8B8" },
    ],
    sizes: ["S", "M", "L", "XL"],
    fabric: "تول + ساتان",
    stock: 40,
    rating: 4.9,
    reviewCount: 58,
    soldCount: 210,
    isFeatured: true,
    isNew: false,
    badge: "خصم 19%",
    tags: ["فستان", "سهرة", "مناسبات"],
  },
  {
    slug: "olive-hijab-set",
    name: "طقم حجاب شيفون زيتي + بندانة",
    nameEn: "Olive Chiffon Hijab Set",
    description:
      "حجاب شيفون ياباني بلون زيتي راقٍ، خفيف ولا يشف، مع بندانة قطنية هدية لثبات مثالي طوال اليوم. أطراف مخيطة بدقة لا تتسلل.",
    details: "• شيفون ياباني فاخر 180×70سم\n• بندانة قطن هدية\n• أطراف مخيطة ليزر\n• لا يحتاج كوي دائم",
    price: 7900,
    compareAtPrice: 9900,
    category: "حجابات",
    categoryEn: "Hijabs",
    collectionSlug: "modest",
    images: [px(38795851), px(20433552), px(19547368)],
    colors: [
      { name: "زيتي", hex: "#5F6650" },
      { name: "بيج", hex: "#D9C6A5" },
      { name: "أسود", hex: "#1D1813" },
      { name: "وردي", hex: "#D9AFA6" },
    ],
    sizes: ["مقاس موحد"],
    fabric: "شيفون ياباني",
    stock: 400,
    rating: 4.6,
    reviewCount: 189,
    soldCount: 1540,
    isFeatured: false,
    isNew: false,
    tags: ["حجاب", "شيفون"],
  },
  {
    slug: "camel-coat-luxe",
    name: "معطف الجمل الفاخر",
    nameEn: "Luxury Camel Coat",
    description:
      "تحفة الشتاء: معطف بلون الجمل من مزيج الصوف والكشمير، بقصّة طويلة مستقيمة وأزرار قرنية. يدفئ حتى 5 درجات ويبقى أنيقاً فوق كل شيء.",
    details:
      "• 70% صوف + 20% كشمير + 10% بولي\n• بطانة ساتان مبطنة\n• جيبان خارجيان + جيب داخلي\n• حزام خصر قابل للفك",
    price: 59900,
    compareAtPrice: 74900,
    category: "معاطف",
    categoryEn: "Coats",
    collectionSlug: "winter",
    images: [px(36180266), px(7760026), px(36180263)],
    colors: [
      { name: "جملي", hex: "#C19A6B" },
      { name: "بني", hex: "#5B3E2E" },
      { name: "أسود", hex: "#1D1813" },
    ],
    sizes: ["S", "M", "L", "XL"],
    fabric: "صوف + كشمير",
    stock: 55,
    rating: 4.9,
    reviewCount: 87,
    soldCount: 320,
    isFeatured: true,
    isNew: true,
    badge: "قطعة الشتاء",
    tags: ["معطف", "شتاء", "صوف"],
  },
  {
    slug: "brown-wool-coat",
    name: "معطف صوف بني بقصّة مستقيمة",
    nameEn: "Brown Wool Coat",
    description:
      "معطف صوف بني دافئ بقصّة عصرية مستقيمة وياقة عريضة تُرفع أيام البرد. خامة ثقيلة بملمس فاخر وتفاصيل خياطة نظيفة.",
    details: "• صوف مضغوط دافئ\n• ياقة عريضة مزدوجة\n• أزرار أمامية + حزام\n• جيبان جانبيان عميقان",
    price: 49900,
    category: "معاطف",
    categoryEn: "Coats",
    collectionSlug: "winter",
    images: [px(12989422), px(22454967), px(19169360)],
    colors: [
      { name: "بني", hex: "#6B4A35" },
      { name: "أسود", hex: "#1D1813" },
    ],
    sizes: ["S", "M", "L", "XL"],
    fabric: "صوف مضغوط",
    stock: 48,
    rating: 4.7,
    reviewCount: 52,
    soldCount: 180,
    isFeatured: false,
    isNew: false,
    tags: ["معطف", "شتاء"],
  },
  {
    slug: "soft-beige-knit",
    name: "كنزة بيج ناعمة بياقة عالية",
    nameEn: "Soft Beige Knit Sweater",
    description:
      "كنزة تريكو ناعمة كالغيمة، بياقة عالية مريحة وأكمام واسعة قليلاً. خامة لا تحك ولا تتوبّر، وتدفئ بدون ثقل. ستحبين ملمسها من أول لمسة.",
    details: "• تريكو ناعم مضاد للتوبير\n• ياقة عالية مريحة\n• قصّة مريحة بطول متوسط\n• تُغسل يدوياً أو غسيل لطيف",
    price: 19900,
    compareAtPrice: 25900,
    category: "كنزات",
    categoryEn: "Knitwear",
    collectionSlug: "winter",
    images: [px(6995886), px(6995890), px(9558698)],
    colors: [
      { name: "بيج", hex: "#E9DDC8" },
      { name: "سكري", hex: "#F3EDE1" },
      { name: "رمادي", hex: "#9A9A9A" },
    ],
    sizes: ["S", "M", "L", "XL"],
    fabric: "أكريليك ناعم + صوف",
    stock: 130,
    rating: 4.8,
    reviewCount: 143,
    soldCount: 890,
    isFeatured: true,
    isNew: false,
    badge: "خصم 23%",
    tags: ["كنزة", "شتاء", "تريكو"],
  },
  {
    slug: "royal-white-thobe",
    name: "ثوب أبيض ملكي ياباني",
    nameEn: "Royal Japanese White Thobe",
    description:
      "ثوب بقماش ياباني فاخر لا يتجعّد بسهولة، بياقة صينية أو عادية حسب اختيارك، وخياطة مخفية دقيقة. بياض ناصع يدوم، وقصّة سعودية أصيلة.",
    details:
      "• قماش ياباني فاخر\n• ياقة صينية أو عادية\n• أزرار مخفية + سحاب\n• خياطة يابانية دقيقة\n• متوفر بتفصيل حسب الطول",
    price: 27900,
    category: "أثواب",
    categoryEn: "Thobes",
    collectionSlug: "essentials",
    images: [px(7129607), px(7129611), px(34171661)],
    colors: [
      { name: "أبيض", hex: "#FFFFFF" },
      { name: "سكري", hex: "#F8F3E8" },
    ],
    sizes: ["52", "54", "56", "58", "60", "62"],
    fabric: "قطن ياباني فاخر",
    stock: 200,
    rating: 4.8,
    reviewCount: 267,
    soldCount: 1980,
    isFeatured: true,
    isNew: false,
    badge: "الأكثر مبيعاً",
    tags: ["ثوب", "رجالي", "يومي"],
  },
  {
    slug: "modern-brown-thobe",
    name: "ثوب شتوي بني بلمسة عصرية",
    nameEn: "Modern Brown Winter Thobe",
    description:
      "ثوب شتوي بقماش أثقل ودفء أعلى، بلون بني ترابي عصري. قصّة مريحة بجيوب جانبية وصدر مخفي الأزرار. أناقة الشتاء للرجل العصري.",
    details: "• قماش شتوي دافئ\n• قصّة عصرية مريحة\n• جيوب جانبية + صدرية\n• مناسب للمناسبات واليومي",
    price: 28900,
    compareAtPrice: 34900,
    category: "أثواب",
    categoryEn: "Thobes",
    collectionSlug: "essentials",
    images: [px(35899781), px(33189244), px(36274669)],
    colors: [
      { name: "بني", hex: "#6B4A35" },
      { name: "زيتي", hex: "#4A4A3A" },
      { name: "كحلي", hex: "#1E2A44" },
    ],
    sizes: ["52", "54", "56", "58", "60"],
    fabric: "بولي قطن شتوي",
    stock: 110,
    rating: 4.7,
    reviewCount: 89,
    soldCount: 520,
    isFeatured: false,
    isNew: true,
    badge: "جديد",
    tags: ["ثوب", "شتاء"],
  },
];

export const seedReviews: SeedReview[] = [
  {
    productSlug: "premium-tee-white",
    author: "محمد الشمري",
    city: "تلمسان",
    rating: 5,
    title: "أفضل تيشيرت جربته",
    body: "الخامة ثقيلة والقصّة مضبوطة، غسلته أكثر من 10 مرات وما تغير اللون ولا تمددت الياقة. طلبت 3 ألوان إضافية.",
    helpful: 42,
  },
  {
    productSlug: "premium-tee-white",
    author: "سارة القحطاني",
    city: "وهران",
    rating: 5,
    title: "ممتاز للاستخدام اليومي",
    body: "أخذته لأخوي وعجبه كثير، القماش مريح وما يشف. التوصيل كان سريع والتغليف راقي.",
    helpful: 18,
  },
  {
    productSlug: "premium-tee-white",
    author: "عبدالله الدوسري",
    city: "الجزائر",
    rating: 4,
    title: "جيد جداً",
    body: "الخامة ممتازة بس أتمنى يتوفر مقاس XXL بكمية أكبر لأنه يخلص بسرعة. بشكل عام يستاهل السعر.",
    helpful: 9,
  },
  {
    productSlug: "iconic-black-hoodie",
    author: "فهد العتيبي",
    city: "تلمسان",
    rating: 5,
    title: "الهودي الأثقل والأفخم",
    body: "جربت هوديات كثيرة من براندات عالمية، هذا يتفوق عليهم بالدفء والخامة. التطريز نظيف والشكل باللبس أحلى من الصور.",
    helpful: 67,
  },
  {
    productSlug: "iconic-black-hoodie",
    author: "نورة المطيري",
    city: "قسنطينة",
    rating: 5,
    title: "هدية ناجحة",
    body: "طلبته هدية لزوجي والمقاس طلع مضبوط حسب جدول المقاسات. دافئ وشكله راقي، شكراً atn+ على الاهتمام بالتفاصيل.",
    helpful: 23,
  },
  {
    productSlug: "iconic-black-hoodie",
    author: "يوسف حمد",
    city: "عنابة",
    rating: 5,
    title: "يستاهل كل ريال",
    body: "وصلني خلال يومين، القماش سميك والبطانة ناعمة. لبسته في سفرة لأوروبا وكان مدفيني تماماً.",
    helpful: 31,
  },
  {
    productSlug: "classic-black-abaya",
    author: "ريم الحربي",
    city: "تلمسان",
    rating: 5,
    title: "عباية العمر",
    body: "ثالث مرة أطلب نفس العباية بأطوال مختلفة لأمي وأختي. القماش ما يتجعّد والسواد فاحم حتى بعد الغسيل. شكراً على الطرحة الهدية!",
    helpful: 89,
  },
  {
    productSlug: "classic-black-abaya",
    author: "أمل الزهراني",
    city: "سطيف",
    rating: 5,
    title: "خياطة نظيفة وقصّة جميلة",
    body: "القصّة انسيابية ومحتشمة بنفس الوقت، والأكمام واسعة ومريحة. المقاس مضبوط حسب الجدول. تجربة شراء راقية من الموقع للتوصيل.",
    helpful: 45,
  },
  {
    productSlug: "classic-black-abaya",
    author: "لطيفة القحطاني",
    city: "بجاية",
    rating: 4,
    title: "جميلة بس الطول",
    body: "العباية فخمة والقماش يجنن، بس انتبهوا للطول، أنا طولي 160 وأخذت 52 وطلعت مضبوطة تماماً. أنصح بمراجعة دليل المقاسات.",
    helpful: 27,
  },
  {
    productSlug: "camel-coat-luxe",
    author: "لينا أحمد",
    city: "تلمسان",
    rating: 5,
    title: "قطعة كوتور",
    body: "المعطف أفخم من الصور بكثير، البطانة نظيفة والخامة دافئة فعلاً. لبسته في زواج وكان الكل يسأل من وين. يستاهل كل ريال.",
    helpful: 34,
  },
  {
    productSlug: "camel-coat-luxe",
    author: "خالد العمري",
    city: "وهران",
    rating: 5,
    title: "هدية لوالدتي",
    body: "طلبته هدية للوالدة والمقاس M طلع ممتاز. التغليف كان فخماً جداً مع كرت إهداء. خدمة عملاء راقية ردت علي واتساب بسرعة.",
    helpful: 12,
  },
  {
    productSlug: "royal-white-thobe",
    author: "سلطان الدوسري",
    city: "تلمسان",
    rating: 5,
    title: "ثوب يشرّف",
    body: "القماش الياباني فعلاً ما يتجعّد بسرعة والبياض ناصع. الخياطة نظيفة والياقة واقفة مضبوط. صار ثوبي الأساسي للدوام والمناسبات.",
    helpful: 51,
  },
  {
    productSlug: "royal-white-thobe",
    author: "أبو فهد",
    city: "القصيم",
    rating: 4,
    title: "ممتاز",
    body: "ثوب مرتب وخامته باردة على الجسم. فقط أتمنى توفير خيار تفصيل الأكمام الطويلة أكثر. بشكل عام أنصح فيه.",
    helpful: 15,
  },
  {
    productSlug: "soft-beige-knit",
    author: "جود العتيبي",
    city: "الطائف",
    rating: 5,
    title: "أنعم كنزة لمستها",
    body: "الملمس فعلاً مثل الغيمة، دافئة وخفيفة بنفس الوقت. اللون البيج أحلى على الطبيعة. غسلتها غسيل لطيف وما توبّرت أبداً.",
    helpful: 29,
  },
  {
    productSlug: "beige-evening-dress",
    author: "شهد الشهري",
    city: "وهران",
    rating: 5,
    title: "فستان الأحلام",
    body: "لبسته في زواج أختي والكل سألني عنه. التطريز ثابت وما تطاير منه شيء، والقماش مريح رغم أنه فخم. المقاس M كان مضبوطاً علي تماماً.",
    helpful: 38,
  },
  {
    productSlug: "gold-embroidered-abaya",
    author: "منيرة السبيعي",
    city: "تلمسان",
    rating: 5,
    title: "فخامة تليق بالمناسبات",
    body: "التطريز الذهبي دقيق وراقي مو مبالغ فيه. العباية ثقيلة بفخامة ووقفتها جميلة. وصلتني بعلبة هدايا تفتح النفس.",
    helpful: 22,
  },
  {
    productSlug: "linen-shirt-beige",
    author: "تركي المطيري",
    city: "تلمسان",
    rating: 5,
    title: "قميص الصيف المثالي",
    body: "خفيف وبارد ومناسب لجو تلمسان. الأزرار الخشبية عاطية شكل مميز. أخذت مقاس M وطلع ممتاز لطولي 175 ووزني 72.",
    helpful: 11,
  },
  {
    productSlug: "olive-hijab-set",
    author: "مريم حسن",
    city: "وهران",
    rating: 4,
    title: "لون راقي وخامة حلوة",
    body: "اللون الزيتي أجمل من الصور، والشيفون ما يشف. البندانة الهدية عملية. فقط أتمنى ألوان أكثر.",
    helpful: 8,
  },
];
