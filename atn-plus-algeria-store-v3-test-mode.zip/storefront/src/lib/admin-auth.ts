import { createHmac, timingSafeEqual } from "crypto";

export const ADMIN_COOKIE = "atn_admin";

function token(secret: string) {
  return createHmac("sha256", secret).update("atn-admin-v1").digest("hex");
}

export function adminSecret() {
  return process.env.ADMIN_SECRET || "";
}

export function makeAdminToken() {
  const secret = adminSecret();
  if (!secret) throw new Error("ADMIN_SECRET is required");
  return token(secret);
}

export function isValidAdminToken(value?: string | null) {
  const secret = adminSecret();
  if (!secret || !value) return false;
  const a = Buffer.from(value);
  const b = Buffer.from(token(secret));
  return a.length === b.length && timingSafeEqual(a, b);
}
