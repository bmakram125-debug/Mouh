export type ShipmentRequest = {
  orderNumber: string;
  customerName: string;
  phone: string;
  city: string;
  address: string;
  amountToCollect: number;
  notes?: string;
};

export async function createYalidineShipment(input: ShipmentRequest) {
  const base = process.env.YALIDINE_API_BASE_URL;
  const token = process.env.YALIDINE_API_TOKEN;
  if (!base || !token) throw new Error("Yalidine API غير مفعّل: أضف YALIDINE_API_BASE_URL و YALIDINE_API_TOKEN بعد الحصول على بيانات الربط من Yalidine.");
  const res = await fetch(`${base.replace(/\/$/, "")}/shipments`, {
    method: "POST",
    headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
    body: JSON.stringify({
      reference: input.orderNumber,
      customer_name: input.customerName,
      phone: input.phone,
      wilaya: input.city,
      address: input.address,
      cod_amount: input.amountToCollect,
      note: input.notes ?? "",
    }),
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data?.message || "فشل إنشاء شحنة Yalidine");
  return data;
}

export function yalidineTrackingUrl(trackingNumber: string) {
  return `https://www.yalidine.com/suivre-un-colis/?tracking=${encodeURIComponent(trackingNumber)}`;
}
