import { db } from "@/db";
import { collections, products, reviews } from "@/db/schema";
import { seedCollections, seedProducts, seedReviews } from "@/lib/seed-data";
import { eq } from "drizzle-orm";

export async function ensureSeeded() {
  try {
    const existing = await db.select({ id: products.id }).from(products).limit(1);
    if (existing.length > 0) return;
  } catch {
    return;
  }

  try {
    // insert collections
    const colIdBySlug = new Map<string, string>();
    for (const c of seedCollections) {
      const [row] = await db
        .insert(collections)
        .values({
          slug: c.slug,
          name: c.name,
          nameEn: c.nameEn,
          tagline: c.tagline,
          description: c.description,
          image: c.image,
          accent: c.accent,
          sort: c.sort,
        })
        .onConflictDoNothing()
        .returning({ id: collections.id, slug: collections.slug });
      if (row) colIdBySlug.set(row.slug, row.id);
    }
    // fetch ids for slugs that already existed
    if (colIdBySlug.size < seedCollections.length) {
      const all = await db.select().from(collections);
      for (const r of all) colIdBySlug.set(r.slug, r.id);
    }

    const prodIdBySlug = new Map<string, string>();
    for (const p of seedProducts) {
      const [row] = await db
        .insert(products)
        .values({
          slug: p.slug,
          name: p.name,
          nameEn: p.nameEn,
          description: p.description,
          details: p.details,
          price: p.price,
          compareAtPrice: p.compareAtPrice ?? null,
          category: p.category,
          categoryEn: p.categoryEn,
          collectionId: colIdBySlug.get(p.collectionSlug) ?? null,
          images: p.images,
          colors: p.colors,
          sizes: p.sizes,
          fabric: p.fabric,
          stock: p.stock,
          rating: p.rating,
          reviewCount: p.reviewCount,
          soldCount: p.soldCount,
          isFeatured: p.isFeatured,
          isNew: p.isNew,
          badge: p.badge ?? null,
          tags: p.tags,
        })
        .onConflictDoNothing()
        .returning({ id: products.id, slug: products.slug });
      if (row) prodIdBySlug.set(row.slug, row.id);
    }
    if (prodIdBySlug.size < seedProducts.length) {
      const all = await db.select().from(products);
      for (const r of all) prodIdBySlug.set(r.slug, r.id);
    }

    for (const r of seedReviews) {
      const pid = prodIdBySlug.get(r.productSlug);
      if (!pid) continue;
      await db.insert(reviews).values({
        productId: pid,
        author: r.author,
        city: r.city,
        rating: r.rating,
        title: r.title,
        body: r.body,
        helpful: r.helpful,
        verified: true,
      });
    }
  } catch {
    // ignore seeding errors — UI falls back to static data
  }
}

export async function getShopData() {
  await ensureSeeded();
  try {
    const [cols, prods] = await Promise.all([
      db.select().from(collections),
      db.select().from(products),
    ]);
    if (prods.length === 0) throw new Error("empty");
    return { collections: cols, products: prods };
  } catch {
    // fallback to static data shaped like db rows
    const cols = seedCollections.map((c, i) => ({
      id: `fallback-col-${i}`,
      slug: c.slug,
      name: c.name,
      nameEn: c.nameEn,
      tagline: c.tagline,
      description: c.description,
      image: c.image,
      accent: c.accent,
      sort: c.sort,
    }));
    const colId = (slug: string) => `fallback-col-${seedCollections.findIndex((c) => c.slug === slug)}`;
    const prods = seedProducts.map((p, i) => ({
      id: `fallback-prod-${i}`,
      slug: p.slug,
      name: p.name,
      nameEn: p.nameEn,
      description: p.description,
      details: p.details,
      price: p.price,
      compareAtPrice: p.compareAtPrice ?? null,
      category: p.category,
      categoryEn: p.categoryEn,
      collectionId: colId(p.collectionSlug),
      images: p.images,
      colors: p.colors,
      sizes: p.sizes,
      fabric: p.fabric,
      stock: p.stock,
      rating: p.rating,
      reviewCount: p.reviewCount,
      soldCount: p.soldCount,
      isFeatured: p.isFeatured,
      isNew: p.isNew,
      badge: p.badge ?? null,
      tags: p.tags,
      createdAt: new Date(),
    }));
    return { collections: cols, products: prods };
  }
}

export async function getProductWithReviews(slug: string) {
  await ensureSeeded();
  try {
    const rows = await db.select().from(products).where(eq(products.slug, slug)).limit(1);
    if (rows.length === 0) return null;
    const product = rows[0];
    const revs = await db
      .select()
      .from(reviews)
      .where(eq(reviews.productId, product.id));
    // related: same collection or category
    const all = await db.select().from(products);
    const related = all.filter((p) => p.slug !== slug).slice(0, 4);
    return { product, reviews: revs, related };
  } catch {
    return null;
  }
}
