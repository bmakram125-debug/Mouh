ALTER TABLE orders ADD COLUMN IF NOT EXISTS payment_provider text NOT NULL DEFAULT 'cod';
ALTER TABLE orders ADD COLUMN IF NOT EXISTS payment_id text;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS shipment_provider text;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS tracking_number text;
CREATE INDEX IF NOT EXISTS orders_payment_id_idx ON orders(payment_id);
CREATE INDEX IF NOT EXISTS orders_tracking_number_idx ON orders(tracking_number);
