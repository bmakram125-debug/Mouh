# ATN+ — متجر ملابس جزائري

تمت تهيئة المشروع ليكون أساس متجر ملابس موجّهًا للجزائر، مع إصلاحات أساسية في إنشاء الطلبات والمخزون.

## ما تم تحديثه
- العملة: الدينار الجزائري (دج / DZD).
- المدن: ولايات الجزائر بدل المدن السعودية.
- الدفع: وضع الاختبار مفعّل افتراضيًا لـ Chargily Pay، مع بقاء الدفع عند الاستلام متاحًا.
- الأسعار التجريبية حُوّلت من قيم SAR القديمة إلى قيم DZD تقريبية (×100)؛ راجعها قبل الإطلاق.
- إنشاء الطلب أصبح يتحقق من السعر الحقيقي في قاعدة البيانات بدل السعر القادم من المتصفح.
- التحقق من المقاس واللون والمخزون على الخادم.
- خصم المخزون وزيادة المبيعات وإنشاء الطلب تتم داخل transaction واحدة.
- لا يتم إرجاع نجاح وهمي إذا فشل حفظ الطلب.
- أكواد الخصم التجريبية: `DZ15` و `DZ10`.

## التشغيل
1. أنشئ PostgreSQL وضع `DATABASE_URL` في `.env.local` اعتمادًا على `.env.example`.
2. ثبّت الحزم: `npm install`.
3. ادفع الـ schema إلى قاعدة البيانات للتجربة: `npm run db:push`.
4. شغّل: `npm run dev`.

## قبل الإنتاج
- إضافة بوابة دفع جزائرية حقيقية (لا تستخدم بيانات بطاقات داخل التطبيق).
- إضافة لوحة إدارة محمية لإدارة المنتجات والمخزون والطلبات.
- إضافة rate limiting وCAPTCHA/anti-spam للتقييمات والـ APIs العامة.
- إضافة شركة شحن واتفاقية أسعار فعلية حسب الولاية.
- مراجعة أسعار المنتجات والصور وحقوق استخدامها.
- تغيير `DATABASE_URL` إلى قاعدة إنتاج آمنة وعدم وضع كلمة المرور في المستودع.
- إنشاء migrations وتطبيقها بدل الاعتماد على `db:push` في الإنتاج.

## لوحة الإدارة
- الرابط: `/admin`
- ضع `ADMIN_PASSWORD` و `ADMIN_SECRET` في `.env.local`.
- إدارة المنتجات: السعر، السعر السابق، المخزون، الصور، المقاسات، التصنيف، المميز والجديد.
- إدارة الطلبات: تغيير الحالة وإنشاء شحنة والحصول على رقم التتبع.

## الدفع الإلكتروني الجزائري
تم تجهيز التكامل مع Chargily Pay V2 عبر CIB وEDAHABIA وChargily App. للاختبار ضع مفتاح Chargily Test في `CHARGILY_SECRET_KEY` واترك `CHARGILY_MODE=test` و`CHARGILY_LIVE=false`. لا تستخدم مفتاح Live في الاختبار.

## الشحن
تم تجهيز Adapter موحد لـ dzship يدعم Yalidine وZR Express وMaystro وNOEST وEcotrack وغيرها. ضع `DZSHIP_COURIER` و`DZSHIP_CREDENTIALS_JSON` حسب شركة الشحن التي لديك معها حساب تجاري.

## الدفع الإلكتروني الجزائري والشحن

تم تجهيز المشروع لبوابة **Chargily Pay** لقبول CIB وEDAHABIA. الوضع الافتراضي `test`، ويجب وضع المفتاح السري في `.env.local`:

```env
CHARGILY_MODE=test
CHARGILY_SECRET_KEY=YOUR_TEST_SECRET
CHARGILY_API_BASE=https://pay.chargily.net/test/api/v2
NEXT_PUBLIC_SITE_URL=https://your-domain.dz
```

عند الدفع الإلكتروني ينشئ المتجر طلبًا بحالة `awaiting_payment` ثم يرسل العميل إلى صفحة Chargily. بعد نجاح الدفع، يستقبل `/api/payments/chargily/webhook` إشعار `checkout.paid` ويحوّل الطلب إلى `paid`. يتم التحقق من توقيع الـ webhook عبر HMAC قبل قبول الحدث.

للدخول إلى الإنتاج استخدم مفتاح Live وقاعدة API الخاصة بالإنتاج، وبعد التأكد من حساب Chargily/التراخيص المطلوبة.

### الشحن

تمت إضافة طبقة شحن مهيأة لـ **Yalidine** مع endpoint داخلي:

`POST /api/shipping/create`

وتحتاج هذه الطبقة إلى بيانات API الرسمية من Yalidine:

```env
YALIDINE_API_BASE_URL=
YALIDINE_API_TOKEN=
```

لا يتم تخمين أو اختلاق endpoint أو token خاص بشركة الشحن. بعد الحصول على بيانات الربط الرسمية، يتم ضبطها في البيئة ويمكن استخدام endpoint إنشاء الشحنة لتسجيل رقم التتبع على الطلب.

### قاعدة البيانات

نفّذ:

```bash
npm run db:push
```

أو طبّق ملف `drizzle/0001_algerian_payments_shipping.sql` على قاعدة البيانات الحالية.


## اختبار الدفع (Test Mode)

الإعداد الافتراضي هو بيئة الاختبار:

```env
CHARGILY_MODE=test
CHARGILY_LIVE=false
CHARGILY_API_BASE=https://pay.chargily.net/test/api/v2
CHARGILY_SECRET_KEY=YOUR_CHARGILY_TEST_SECRET
NEXT_PUBLIC_SITE_URL=http://localhost:3000
```

بعد وضع مفتاح الاختبار شغّل المتجر، اختر **الدفع الإلكتروني CIB / EDAHABIA** من Checkout، ثم اختبر دورة الدفع حتى العودة إلى صفحة نجاح الطلب. لا تضع مفاتيح حقيقية داخل Git أو داخل ملف ZIP.
